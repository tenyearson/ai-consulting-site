'use client'

import { useState } from 'react'
import { Github, ExternalLink, Cpu, Zap, Users, Code } from 'lucide-react'

// 模拟Agent应用数据
const mockAgentApps = [
  {
    id: 1,
    name: 'AutoGPT',
    description: '自主AI代理，可分解复杂任务并自动执行',
    category: '自主代理',
    githubStars: '85k',
    useCase: '研究辅助、数据分析、自动化工作流',
    painPoints: ['任务分解困难', '多步骤执行', '上下文管理'],
    githubLink: 'https://github.com/Significant-Gravitas/AutoGPT',
    status: '活跃开发',
  },
  {
    id: 2,
    name: 'LangChain',
    description: '构建LLM应用的框架，支持多种模型和工具集成',
    category: '开发框架',
    githubStars: '72k',
    useCase: '聊天机器人、文档分析、智能助手',
    painPoints: ['模型集成复杂', '工具链管理', '状态维护'],
    githubLink: 'https://github.com/langchain-ai/langchain',
    status: '企业级',
  },
  {
    id: 3,
    name: 'BabyAGI',
    description: '基于任务驱动的自主AI代理系统',
    category: '任务代理',
    githubStars: '25k',
    useCase: '项目管理、自动化调度、目标追踪',
    painPoints: ['长期规划', '优先级管理', '资源分配'],
    githubLink: 'https://github.com/yoheinakajima/babyagi',
    status: '实验性',
  },
  {
    id: 4,
    name: 'CrewAI',
    description: '多智能体协作框架，模拟团队工作流程',
    category: '多智能体',
    githubStars: '18k',
    useCase: '团队协作、复杂问题解决、分布式决策',
    painPoints: ['智能体协调', '通信协议', '冲突解决'],
    githubLink: 'https://github.com/joaomdmoura/crewai',
    status: '快速增长',
  },
]

const categories = ['全部', '自主代理', '开发框架', '任务代理', '多智能体', '专业领域']

export default function AgentAppsSection() {
  const [selectedCategory, setSelectedCategory] = useState('全部')
  const [expandedId, setExpandedId] = useState<number | null>(null)

  const filteredApps = selectedCategory === '全部' 
    ? mockAgentApps 
    : mockAgentApps.filter(app => app.category === selectedCategory)

  const handleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id)
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      {/* 标题和统计 */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold flex items-center">
          <Cpu className="mr-3 h-6 w-6 text-purple-500" />
          Agent应用案例
          <span className="ml-3 text-sm font-normal text-gray-500 dark:text-gray-400">
            开源项目 • 实际应用
          </span>
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          追踪最新AI Agent开源项目、应用场景和解决方案
        </p>
      </div>

      {/* 分类筛选 */}
      <div className="mb-6">
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === category
                  ? 'bg-purple-500 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* 应用列表 */}
      <div className="space-y-4">
        {filteredApps.map((app) => (
          <div
            key={app.id}
            className={`border rounded-lg overflow-hidden transition-all duration-300 ${
              expandedId === app.id
                ? 'border-purple-300 dark:border-purple-700 bg-purple-50 dark:bg-purple-900/20'
                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
            }`}
          >
            {/* 应用头部 */}
            <div 
              className="p-4 cursor-pointer"
              onClick={() => handleExpand(app.id)}
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    <span className="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-xs font-medium">
                      {app.category}
                    </span>
                    <span className="mx-3 text-gray-400">•</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                      <Github className="h-4 w-4 mr-1" />
                      {app.githubStars} stars
                    </span>
                    <span className="mx-3 text-gray-400">•</span>
                    <span className={`text-sm px-2 py-1 rounded ${
                      app.status === '企业级' ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300' :
                      app.status === '活跃开发' ? 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300' :
                      'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-300'
                    }`}>
                      {app.status}
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-semibold mb-2">
                    {app.name}
                  </h3>
                  
                  <p className="text-gray-600 dark:text-gray-400 mb-3">
                    {app.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span className="flex items-center">
                        <Zap className="h-4 w-4 mr-1" />
                        应用场景
                      </span>
                      <span className="text-gray-700 dark:text-gray-300">
                        {app.useCase.split('、')[0]}...
                      </span>
                    </div>
                    
                    <button className="text-purple-500 hover:text-purple-600 text-sm font-medium">
                      {expandedId === app.id ? '收起详情' : '查看详情'}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* 展开的详情 */}
            {expandedId === app.id && (
              <div className="px-4 pb-4 pt-2 border-t border-gray-200 dark:border-gray-700 animate-slide-up">
                {/* 解决的问题 */}
                <div className="mb-4">
                  <h4 className="font-medium mb-2 flex items-center">
                    <Users className="h-4 w-4 mr-2" />
                    解决的痛点
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {app.painPoints.map((point, index) => (
                      <span 
                        key={index}
                        className="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-sm"
                      >
                        {point}
                      </span>
                    ))}
                  </div>
                </div>
                
                {/* 安装和使用 */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <h4 className="font-medium mb-2">安装方式</h4>
                    <div className="bg-gray-50 dark:bg-gray-900 rounded p-3 font-mono text-sm">
                      <p className="text-gray-700 dark:text-gray-300"># 使用pip安装</p>
                      <p className="text-blue-600 dark:text-blue-400">pip install {app.name.toLowerCase()}</p>
                      <p className="text-gray-500 text-xs mt-2">或参考GitHub文档</p>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">技术栈</h4>
                    <div className="flex flex-wrap gap-2">
                      <span className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300 rounded-full text-sm">
                        Python
                      </span>
                      <span className="px-3 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 rounded-full text-sm">
                        LLM集成
                      </span>
                      <span className="px-3 py-1 bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 rounded-full text-sm">
                        API服务
                      </span>
                    </div>
                  </div>
                </div>
                
                {/* 行动按钮 */}
                <div className="flex flex-wrap gap-3">
                  <a
                    href={app.githubLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-4 py-2 bg-gray-900 hover:bg-black text-white rounded-lg text-sm font-medium transition-colors"
                  >
                    <Github className="h-4 w-4 mr-2" />
                    查看GitHub
                  </a>
                  <a
                    href={`${app.githubLink}#readme`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-lg text-sm font-medium transition-colors"
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    查看文档
                  </a>
                  <button className="inline-flex items-center px-4 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-sm font-medium transition-colors">
                    <Code className="h-4 w-4 mr-2" />
                    快速开始
                  </button>
                </div>
                
                {/* 技术说明 */}
                <div className="mt-4 text-xs text-gray-500">
                  <p>🔧 技术架构: 基于现代AI框架，支持主流LLM提供商</p>
                  <p className="mt-1">📈 社区状态: {app.status}，{app.githubStars} GitHub stars</p>
                  <p className="mt-1">🎯 适用场景: {app.useCase}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* 底部统计 */}
      <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
        <div className="flex flex-col sm:flex-row justify-between items-center">
          <div className="text-sm text-gray-500 mb-4 sm:mb-0">
            共 {filteredApps.length} 个Agent应用 • 总GitHub Stars: 200k+
          </div>
          <div className="flex space-x-3">
            <button className="px-4 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-sm font-medium transition-colors">
              查看更多
            </button>
            <button className="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-lg text-sm font-medium transition-colors">
              提交项目
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}