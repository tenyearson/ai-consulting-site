import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import PlatformDetector from '@/components/PlatformDetector'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'AI大模型咨询平台 - 前沿资讯与应用',
  description: '每日更新AI大模型前沿研究、Agent应用、智能建造领域最新成果',
  keywords: ['AI', '大模型', 'Agent', '智能建造', '前沿资讯', '研究成果'],
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="zh-CN" className="scroll-smooth">
      <body className={`${inter.className} bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100`}>
        <PlatformDetector />
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-grow container-responsive py-6">
            {children}
          </main>
          <Footer />
        </div>
      </body>
    </html>
  )
}