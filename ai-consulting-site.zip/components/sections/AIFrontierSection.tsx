'use client'

import { useState } from 'react'
import { Brain, Cpu, Zap, TrendingUp, Globe, Code, Clock, ExternalLink, BarChart, Video } from 'lucide-react'

// AI前沿资讯数据
const frontierNews = [
  {
    id: 1,
    title: 'GPT-5技术架构泄露：万亿参数混合专家模型',
    category: '大模型突破',
    date: '2026-04-05',
    source: 'AI Research Weekly',
    summary: '据泄露的技术文档显示，GPT-5将采用混合专家架构，参数量达到1.8万亿，推理成本降低40%',
    impact: '高',
    tags: ['GPT-5', 'MoE', '成本优化', '推理加速'],
    details: [
      '采用128个专家模型混合架构',
      '上下文长度扩展到128K tokens',
      '多模态能力大幅增强',
      '推理速度提升60%',
      '训练成本降低30%'
    ],
    link: 'https://example.com/gpt5-leak',
    readingTime: '5分钟'
  },
  {
    id: 2,
    title: '谷歌Gemini 2.0发布：原生多模态理解能力',
    category: '多模态AI',
    date: '2026-04-03',
    source: 'Google AI Blog',
    summary: 'Gemini 2.0实现真正的原生多模态理解，无需模态转换，直接处理图像、音频、视频、文本',
    impact: '高',
    tags: ['Gemini', '多模态', '原生理解', '谷歌'],
    details: [
      '原生多模态架构，无需模态转换',
      '支持8种模态同时输入',
      '视频理解能力提升300%',
      '实时多模态对话',
      '开源基础版本'
    ],
    link: 'https://ai.google/gemini2',
    readingTime: '4分钟'
  },
  {
    id: 3,
    title: 'Llama 4开源发布：700亿参数，性能接近GPT-4',
    category: '开源生态',
    date: '2026-04-01',
    source: 'Meta AI',
    summary: 'Meta发布Llama 4，700亿参数模型在多项基准测试中接近GPT-4水平，完全开源',
    impact: '中高',
    tags: ['Llama', '开源', 'Meta', '性能突破'],
    details: [
      '700亿参数，性能接近GPT-4',
      '完全开源，商业友好许可',
      '支持128K上下文',
      '推理优化，可在消费级GPU运行',
      '多语言能力大幅增强'
    ],
    link: 'https://llama.meta.com',
    readingTime: '6分钟'
  },
  {
    id: 4,
    title: '英伟达B200芯片发布：AI算力再翻倍',
    category: '硬件算力',
    date: '2026-03-30',
    source: 'NVIDIA GTC',
    summary: '英伟达发布Blackwell架构B200芯片，AI训练性能提升2.5倍，能效提升25倍',
    impact: '高',
    tags: ['英伟达', 'B200', '算力', '硬件'],
    details: [
      '2080亿晶体管，台积电4nm工艺',
      'AI训练性能提升2.5倍',
      '能效比提升25倍',
      '支持10TB/s显存带宽',
      '大规模集群效率提升'
    ],
    link: 'https://nvidia.com/gtc',
    readingTime: '7分钟'
  },
  {
    id: 5,
    title: '中国发布"智源2.0"大模型：中文理解领先',
    category: '国内动态',
    date: '2026-03-28',
    source: '智源研究院',
    summary: '智源研究院发布2.0版本大模型，在中文理解和推理任务上达到国际领先水平',
    impact: '中',
    tags: ['智源', '中文大模型', '国产AI', '研究突破'],
    details: [
      '中文理解能力国际领先',
      '参数量1300亿',
      '支持法律、医疗等专业领域',
      '开源基础版本',
      '与产业深度合作'
    ],
    link: 'https://zhiyuan.ai',
    readingTime: '5分钟'
  },
  {
    id: 6,
    title: 'AI编程助手普及：GitHub Copilot用户突破5000万',
    category: '行业应用',
    date: '2026-03-25',
    source: 'GitHub',
    summary: 'GitHub Copilot用户数突破5000万，开发者生产力平均提升55%',
    impact: '中',
    tags: ['Copilot', '编程助手', '开发者工具', 'GitHub'],
    details: [
      '全球用户突破5000万',
      '开发者生产力提升55%',
      '代码质量提升40%',
      '支持30+编程语言',
      '企业采用率85%'
    ],
    link: 'https://github.com/copilot',
    readingTime: '3分钟'
  }
]

// 技术趋势分类
const techTrends = [
  {
    category: '大模型技术',
    trends: [
      '混合专家架构成为主流',
      '上下文长度持续扩展',
      '推理成本大幅降低',
      '多模态能力增强'
    ],
    icon: <Brain className="h-5 w-5" />
  },
  {
    category: '硬件发展',
    trends: [
      '专用AI芯片性能翻倍',
      '能效比持续优化',
      '边缘AI设备普及',
      '量子计算探索'
    ],
    icon: <Cpu className="h-5 w-5" />
  },
  {
    category: '开源生态',
    trends: [
      '开源模型性能接近闭源',
      '社区贡献活跃度提升',
      '商业化模式成熟',
      '多语言支持完善'
    ],
    icon: <Code className="h-5 w-5" />
  },
  {
    category: '行业应用',
    trends: [
      'AI编程助手普及',
      '垂直领域模型涌现',
      '企业采用率快速提升',
      '监管框架逐步建立'
    ],
    icon: <Globe className="h-5 w-5" />
  }
]

export default function AIFrontierSection() {
  const [expandedNews, setExpandedNews] = useState<number | null>(1)
  const [filter, setFilter] = useState<string>('all')

  const handleExpand = (id: number) => {
    setExpandedNews(expandedNews === id ? null : id)
  }

  const filteredNews = filter === 'all' 
    ? frontierNews 
    : frontierNews.filter(news => news.tags.includes(filter))

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      {/* 标题和价值主张 */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold flex items-center text-purple-700 dark:text-purple-400">
          <Brain className="mr-3 h-7 w-7" />
          AI前沿资讯 · 趋势洞察
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mt-3 text-lg">
          追踪最新AI研究成果、技术突破和行业动态，保持技术前沿敏感度
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="px-3 py-1 bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 rounded-full text-sm">
            技术追踪
          </span>
          <span className="px-3 py-1 bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 rounded-full text-sm">
            趋势洞察
          </span>
          <span className="px-3 py-1 bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 rounded-full text-sm">
            行业动态
          </span>
          <span className="px-3 py-1 bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 rounded-full text-sm">
            研究突破
          </span>
        </div>
      </div>

      {/* 技术趋势概览 */}
      <div className="mb-8">
        <h3 className="text-lg font-bold mb-4 flex items-center">
          <TrendingUp className="h-5 w-5 mr-2 text-purple-500" />
          当前技术趋势概览
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {techTrends.map((trend, index) => (
            <div key={index} className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
              <div className="flex items-center mb-3">
                <div className="p-2 bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-400 rounded-lg mr-3">
                  {trend.icon}
                </div>
                <div className="font-medium">{trend.category}</div>
              </div>
              <ul className="space-y-2">
                {trend.trends.map((item, idx) => (
                  <li key={idx} className="text-sm text-gray-600 dark:text-gray-400 flex items-start">
                    <span className="text-purple-500 mr-2">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* 过滤标签 */}
      <div className="mb-6">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'all'
                ? 'bg-purple-500 text-white'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
            }`}
          >
            全部资讯
          </button>
          <button
            onClick={() => setFilter('GPT-5')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'GPT-5'
                ? 'bg-purple-500 text-white'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
            }`}
          >
            大模型突破
          </button>
          <button
            onClick={() => setFilter('多模态')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === '多模态'
                ? 'bg-purple-500 text-white'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
            }`}
          >
            多模态AI
          </button>
          <button
            onClick={() => setFilter('开源')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === '开源'
                ? 'bg-purple-500 text-white'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
            }`}
          >
            开源生态
          </button>
          <button
            onClick={() => setFilter('算力')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === '算力'
                ? 'bg-purple-500 text-white'
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
            }`}
          >
            硬件算力
          </button>
        </div>
      </div>

      {/* 资讯列表 */}
      <div className="space-y-4">
        {filteredNews.map((news) => (
          <div
            key={news.id}
            className={`border rounded-lg overflow-hidden transition-all duration-300 ${
              expandedNews === news.id
                ? 'border-purple-300 dark:border-purple-700 bg-purple-50 dark:bg-purple-900/20'
                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
            }`}
          >
            {/* 资讯头部 */}
            <div 
              className="p-5 cursor-pointer"
              onClick={() => handleExpand(news.id)}
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center mb-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      news.impact === '高' 
                        ? 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-300'
                        : news.impact === '中高'
                        ? 'bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-300'
                        : 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300'
                    }`}>
                      影响度：{news.impact}
                    </span>
                    <span className="mx-3 text-gray-400">•</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {news.date}
                    </span>
                    <span className="mx-3 text-gray-400">•</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {news.readingTime}
                    </span>
                  </div>
                  
                  <h3 className="text-xl font-semibold mb-3">
                    {news.title}
                  </h3>
                  
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    {news.summary}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="text-sm text-gray-500">
                        来源：{news.source}
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {news.tags.map((tag, index) => (
                          <span key={index} className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-xs">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <button className="text-purple-500 hover:text-purple-600 text-sm font-medium">
                      {expandedNews === news.id ? '收起详情' : '查看技术细节'}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* 展开的详情 */}
            {expandedNews === news.id && (
              <div className="px-5 pb-5 pt-3 border-t border-gray-200 dark:border-gray-700 animate-slide-up">
                {/* 技术细节 */}
                <div className="mb-6">
                  <h4 className="font-medium mb-3 flex items-center text-purple-600 dark:text-purple-400">
                    <BarChart className="h-5 w-5 mr-2" />
                    技术细节和突破点
                  </h4>
                  <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
                    <ul className="space-y-3">
                      {news.details.map((detail, index) => (
                        <li key={index} className="flex items-start">
                          <div className="w-6 h-6 flex items-center justify-center bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 rounded-full text-xs font-bold mr-3 mt-0.5">
                            {index + 1}
                          </div>
                          <div className="flex-1 text-gray-700 dark:text-gray-300">
                            {detail}
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                {/* 影响分析 */}
                <div className="mb-6">
                  <h4 className="font-medium mb-3">行业影响分析</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg">
                      <div className="font-medium mb-2">技术影响</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {news.impact === '高' ? '重大技术突破，可能改变技术路线' :
                         news.impact === '中高' ? '重要技术进步，推动行业发展' :
                         '渐进式改进，优化现有技术'}
                      </div>
                    </div>
                    <div className="p-4 bg-green-50 dark:bg-green-900/30 rounded-lg">
                      <div className="font-medium mb-2">商业影响</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {news.impact === '高' ? '可能创造新市场，改变竞争格局' :
                         news.impact === '中高' ? '提升企业竞争力，降低成本' :
                         '渐进式商业价值，优化现有业务'}
                      </div>
                    </div>
                    <div className="p-4 bg-orange-50 dark:bg-orange-900/30 rounded-lg">
                      <div className="font-medium mb-2">个人影响</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {news.impact === '高' ? '需要关注并学习新技术方向' :
                         news.impact === '中高' ? '建议了解并评估应用价值' :
                         '了解即可，保持技术敏感度'}
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* 行动建议 */}
                <div className="mb-6">
                  <h4 className="font-medium mb-3">行动建议</h4>
                  <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <div className="font-medium mb-2">短期行动（1-2周）</div>
                        <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                          <li className="flex items-start">
                            <span className="text-purple-500 mr-2">•</span>
                            <span>阅读原文报道和技术文档</span>
                          </li>
                          <li className="flex items-start">
                            <span className="text-purple-500 mr-2">•</span>
                            <span>关注相关社区讨论和解读</span>
                          </li>
                          <li className="flex items-start">
                            <span className="text-purple-500 mr-2">•</span>
                            <span>评估对个人/项目的影响</span>
                          </li>
                        </ul>
                      </div>
                      <div>
                        <div className="font-medium mb-2">长期关注（1-3月）</div>
                        <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                          <li className="flex items-start">
                            <span className="text-purple-500 mr-2">•</span>
                            <span>跟踪技术发展和应用案例</span>
                          </li>
                          <li className="flex items-start">
                            <span className="text-purple-500 mr-2">•</span>
                            <span>学习相关技术和工具</span>
                          </li>
                          <li className="flex items-start">
                            <span className="text-purple-500 mr-2">•</span>
                            <span>考虑技术迁移和应用</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* 原文链接 */}
                <div className="flex justify-between items-center">
                  <div className="text-sm text-gray-500">
                    获取完整信息和深度分析
                  </div>
                  <a
                    href={news.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-lg font-medium flex items-center transition-colors"
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    阅读原文报道
                  </a>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* 资讯订阅 */}
      <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h4 className="font-medium mb-2">获取深度技术分析</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              每周精选AI前沿资讯，深度技术解读，行业趋势分析
            </p>
          </div>
          <div className="flex space-x-3">
            <button className="px-5 py-2.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg font-medium transition-colors">
              订阅周报
            </button>
            <button className="px-5 py-2.5 bg-purple-500 hover:bg-purple-600 text-white rounded-lg font-medium transition-colors flex items-center">
              <Video className="h-4 w-4 mr-2" />
              观看技术解读视频
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}