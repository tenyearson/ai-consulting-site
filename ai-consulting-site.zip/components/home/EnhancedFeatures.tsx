'use client'

import { useState, useEffect } from 'react'
import { Eye, Tag, MessageSquare, TrendingUp, ThumbsUp, ThumbsDown } from 'lucide-react'

export default function EnhancedFeatures() {
  const [viewCount, setViewCount] = useState(0)
  const [interests, setInterests] = useState<string[]>([])
  const [feedback, setFeedback] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const [likes, setLikes] = useState(0)
  const [dislikes, setDislikes] = useState(0)

  // 模拟浏览量增长
  useEffect(() => {
    const initialViews = Math.floor(Math.random() * 1000) + 500
    setViewCount(initialViews)
    
    // 每30秒增加一些浏览量
    const interval = setInterval(() => {
      setViewCount(prev => prev + Math.floor(Math.random() * 5) + 1)
    }, 30000)
    
    return () => clearInterval(interval)
  }, [])

  // 兴趣点分类
  const interestTags = [
    '智能建造', '工业能源', 'AI工具', '前沿技术', '个人发展',
    '政策分析', '市场调研', '效率提升', '技术趋势', '创业指导'
  ]

  const handleInterestClick = (tag: string) => {
    if (interests.includes(tag)) {
      setInterests(interests.filter(t => t !== tag))
    } else {
      setInterests([...interests, tag])
    }
  }

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (feedback.trim()) {
      console.log('反馈提交:', { feedback, interests, likes, dislikes })
      setSubmitted(true)
      setTimeout(() => setSubmitted(false), 3000)
      setFeedback('')
    }
  }

  return (
    <div className="bg-gradient-to-br from-gray-50 to-white dark:from-gray-800 dark:to-gray-900 rounded-2xl p-6 mb-8 border border-gray-200 dark:border-gray-700">
      <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-gray-200">
        用户互动与数据分析
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* 浏览量统计 */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-blue-200 dark:border-blue-800">
          <div className="flex items-center mb-4">
            <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg mr-3">
              <Eye className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-800 dark:text-gray-200">实时浏览量</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">今日访问统计</p>
            </div>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold text-blue-600 dark:text-blue-400">{viewCount.toLocaleString()}</p>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
              <TrendingUp className="inline w-4 h-4 text-green-500 mr-1" />
              较昨日 +{Math.floor(viewCount * 0.15).toLocaleString()}
            </p>
          </div>
        </div>

        {/* 兴趣点分类 */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-purple-200 dark:border-purple-800">
          <div className="flex items-center mb-4">
            <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg mr-3">
              <Tag className="h-6 w-6 text-purple-600 dark:text-purple-400" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-800 dark:text-gray-200">兴趣点分类</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">点击选择您的兴趣</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {interestTags.map(tag => (
              <button
                key={tag}
                onClick={() => handleInterestClick(tag)}
                className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                  interests.includes(tag)
                    ? 'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300 border border-purple-300 dark:border-purple-700'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
          {interests.length > 0 && (
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-3">
              已选择: {interests.join(', ')}
            </p>
          )}
        </div>

        {/* 热点反馈收集 */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-green-200 dark:border-green-800">
          <div className="flex items-center mb-4">
            <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg mr-3">
              <MessageSquare className="h-6 w-6 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-800 dark:text-gray-200">热点反馈</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">分享您的想法</p>
            </div>
          </div>
          
          <div className="flex justify-center space-x-4 mb-4">
            <button
              onClick={() => setLikes(likes + 1)}
              className="flex items-center space-x-1 px-3 py-1.5 bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-300 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/50"
            >
              <ThumbsUp className="w-4 h-4" />
              <span>有用 ({likes})</span>
            </button>
            <button
              onClick={() => setDislikes(dislikes + 1)}
              className="flex items-center space-x-1 px-3 py-1.5 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/50"
            >
              <ThumbsDown className="w-4 h-4" />
              <span>改进 ({dislikes})</span>
            </button>
          </div>

          <form onSubmit={handleFeedbackSubmit}>
            <textarea
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="请分享您的建议或需求..."
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
              rows={2}
            />
            <button
              type="submit"
              disabled={!feedback.trim()}
              className="mt-2 w-full px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors"
            >
              {submitted ? '感谢反馈！' : '提交反馈'}
            </button>
          </form>
        </div>
      </div>

      <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
        <p className="text-sm text-gray-600 dark:text-gray-400 text-center">
          数据仅用于改善用户体验，不会收集个人隐私信息
        </p>
      </div>
    </div>
  )
}