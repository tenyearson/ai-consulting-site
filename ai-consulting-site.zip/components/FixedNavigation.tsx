'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Building2, Cpu, Wrench, Newspaper, GraduationCap, Menu, X } from 'lucide-react'

const navigationItems = [
  { name: '首页', href: '/', icon: <Home className="h-5 w-5" />, color: 'gray' },
  { name: '智能建造', href: '/smart-construction', icon: <Building2 className="h-5 w-5" />, color: 'blue' },
  { name: 'Agent应用', href: '/vertical-agents', icon: <Cpu className="h-5 w-5" />, color: 'green' },
  { name: 'AI工具链', href: '/personal-tools', icon: <Wrench className="h-5 w-5" />, color: 'orange' },
  { name: 'AI前沿', href: '/ai-frontier', icon: <Newspaper className="h-5 w-5" />, color: 'purple' },
  { name: '个人指南', href: '/personal-development', icon: <GraduationCap className="h-5 w-5" />, color: 'yellow' },
]

export default function FixedNavigation() {
  const pathname = usePathname()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const isActive = (href: string) => {
    if (href === '/') {
      return pathname === '/'
    }
    return pathname?.startsWith(href)
  }

  return (
    <>
      {/* 桌面端导航 */}
      <nav className="hidden md:flex fixed top-0 left-0 right-0 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 z-50 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center">
              <div className="text-2xl font-bold bg-gradient-to-r from-blue-600 via-green-600 to-purple-600 bg-clip-text text-transparent">
                AI咨询平台
              </div>
              <div className="ml-4 text-sm text-gray-500 dark:text-gray-400 hidden lg:block">
                五层价值体系 · 从产业到个人的完整指南
              </div>
            </div>

            {/* 导航链接 */}
            <div className="flex space-x-1">
              {navigationItems.map((item) => {
                const active = isActive(item.href)
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`
                      flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-colors
                      ${active 
                        ? `bg-${item.color}-50 dark:bg-${item.color}-900/30 text-${item.color}-700 dark:text-${item.color}-400 border border-${item.color}-200 dark:border-${item.color}-700`
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                      }
                    `}
                  >
                    <span className={`mr-2 ${active ? `text-${item.color}-500` : 'text-gray-400'}`}>
                      {item.icon}
                    </span>
                    {item.name}
                  </Link>
                )
              })}
            </div>
          </div>
        </div>
      </nav>

      {/* 移动端导航 */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 z-50">
        <div className="flex justify-around items-center h-16">
          {navigationItems.map((item) => {
            const active = isActive(item.href)
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`
                  flex flex-col items-center justify-center px-2 py-1 text-xs
                  ${active 
                    ? `text-${item.color}-600 dark:text-${item.color}-400`
                    : 'text-gray-500 dark:text-gray-400'
                  }
                `}
              >
                <div className={`mb-1 ${active ? `text-${item.color}-500` : 'text-gray-400'}`}>
                  {item.icon}
                </div>
                <span className="font-medium">{item.name}</span>
              </Link>
            )
          })}
        </div>
      </nav>

      {/* 移动端汉堡菜单按钮（顶部） */}
      <button
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        className="md:hidden fixed top-4 right-4 z-50 p-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg"
      >
        {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </button>

      {/* 移动端全屏菜单 */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 bg-white dark:bg-gray-900 z-40 pt-20">
          <div className="container mx-auto px-6">
            <div className="space-y-4">
              {navigationItems.map((item) => {
                const active = isActive(item.href)
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`
                      flex items-center p-4 rounded-xl text-lg font-medium
                      ${active 
                        ? `bg-${item.color}-50 dark:bg-${item.color}-900/30 text-${item.color}-700 dark:text-${item.color}-400`
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                      }
                    `}
                  >
                    <span className={`mr-4 ${active ? `text-${item.color}-500` : 'text-gray-400'}`}>
                      {item.icon}
                    </span>
                    {item.name}
                    {active && (
                      <span className="ml-auto text-sm bg-gray-200 dark:bg-gray-700 px-2 py-1 rounded">
                        当前
                      </span>
                    )}
                  </Link>
                )
              })}
            </div>
            
            <div className="mt-8 p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
              <h4 className="font-medium mb-2">导航说明</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                点击任意分类进入详细页面，每层独立解决特定问题，共同构成AI时代的完整生存和发展指南。
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 导航占位符（防止内容被导航遮挡） */}
      <div className="h-16 md:block hidden"></div>
      <div className="h-16 md:hidden block"></div>
    </>
  )
}