import FixedNavigation from '@/components/FixedNavigation'
import DimensionCard from '@/components/DimensionCard'
import { Building2, TrendingUp, Cpu, CpuIcon, DraftingCompass, Construction, Target, Zap, Users, Clock, Download } from 'lucide-react'

// 6大维度专业内容
const professionalDimensions = [
  {
    id: 1,
    title: '行业政策前沿',
    subtitle: '政策解读 · 标准更新 · 补贴申请',
    description: '跟踪建筑行业最新政策法规、标准规范、监管要求、补贴政策，提供政策影响分析和应对策略',
    icon: <Building2 className="h-8 w-8" />,
    color: 'blue',
    stats: '每日更新政策动态',
    features: [
      '智能建造政策支持',
      'BIM强制应用进展',
      '绿色建筑碳中和政策',
      '工程质量安全新规',
      '数字化转型补贴'
    ],
    painPoints: [
      '政策更新快，跟踪困难',
      '标准规范理解偏差',
      '补贴申请流程复杂',
      '合规风险控制难'
    ],
    solutions: [
      'AI政策跟踪分析',
      '智能合规检查',
      '自动化申请助手',
      '风险预警系统'
    ],
    href: '/policy-frontier',
    cta: '查看政策解读'
  },
  {
    id: 2,
    title: '行业发展前沿',
    subtitle: '趋势分析 · 市场动态 · 竞争情报',
    description: '分析建筑行业技术发展趋势、市场动态变化、竞争格局演变、商业模式创新和供应链数字化',
    icon: <TrendingUp className="h-8 w-8" />,
    color: 'green',
    stats: '1568+行业数据点',
    features: [
      '数字孪生全生命周期应用',
      '装配式建筑技术进展',
      '新型建筑材料研发',
      'EPC模式创新',
      '供应链数字化'
    ],
    painPoints: [
      '技术趋势把握不准',
      '市场竞争压力大',
      '商业模式创新难',
      '供应链管理复杂'
    ],
    solutions: [
      '市场趋势预测AI',
      '竞争情报分析系统',
      '商业模式优化算法',
      '供应链智能调度'
    ],
    href: '/industry-frontier',
    cta: '分析行业趋势'
  },
  {
    id: 3,
    title: 'AGENT前沿',
    subtitle: '工程Agent应用 · 落地案例 · 工具推荐',
    description: '探索AI Agent在结构工程领域的具体应用场景、实施案例、工具平台和效果评估方法',
    icon: <Cpu className="h-8 w-8" />,
    color: 'purple',
    stats: '89个工程Agent案例',
    features: [
      '设计优化Agent',
      '施工管理Agent',
      '运维监控Agent',
      '成本控制Agent',
      '合规审查Agent'
    ],
    painPoints: [
      '设计效率低，重复计算多',
      '施工管理粗放',
      '运维数据缺失',
      '成本控制不精准'
    ],
    solutions: [
      '自动化方案生成Agent',
      '智能进度监控Agent',
      '预测性维护Agent',
      '智能造价管理Agent'
    ],
    href: '/agent-frontier',
    cta: '探索Agent应用'
  },
  {
    id: 4,
    title: 'AI前沿',
    subtitle: '结构工程AI技术 · 算法研究 · 实践指南',
    description: '深入研究AI技术在结构工程的具体应用、算法突破、实践方法和学习路径',
    icon: <CpuIcon className="h-8 w-8" />,
    color: 'orange',
    stats: '42个AI工程应用',
    features: [
      'AI辅助结构分析优化',
      '机器学习荷载预测',
      '计算机视觉质量检测',
      '自然语言处理文档管理',
      '强化学习施工调度'
    ],
    painPoints: [
      '结构计算工作繁琐',
      '荷载预测不准确',
      '质量检测效率低',
      '文档管理混乱'
    ],
    solutions: [
      'AI结构优化算法',
      '智能荷载预测模型',
      '自动化质量检测系统',
      '智能文档管理平台'
    ],
    href: '/ai-engineering',
    cta: '学习AI技术'
  },
  {
    id: 5,
    title: '智能设计前沿',
    subtitle: '设计工具 · 方法创新 · 流程优化',
    description: '关注设计工具智能化、设计方法创新、设计流程优化、多专业协同和设计成果数字化',
    icon: <DraftingCompass className="h-8 w-8" />,
    color: 'teal',
    stats: '35+智能设计工具',
    features: [
      '参数化和生成式设计',
      'AI驱动结构优化',
      '自动化出图文档生成',
      '多专业协同平台',
      'VR/AR设计评审'
    ],
    painPoints: [
      '设计工具学习成本高',
      '多专业协同困难',
      '出图工作繁琐易错',
      '设计评审效率低'
    ],
    solutions: [
      '智能设计助手',
      '协同设计平台',
      '自动化出图系统',
      '虚拟现实评审工具'
    ],
    href: '/smart-design',
    cta: '优化设计流程'
  },
  {
    id: 6,
    title: '智能建造前沿',
    subtitle: '施工技术 · 智能设备 · 管理平台',
    description: '追踪施工技术创新、施工设备智能化、施工管理数字化、质量安全监控和数字化交付运维',
    icon: <Construction className="h-8 w-8" />,
    color: 'red',
    stats: '28个智能建造案例',
    features: [
      '机器人施工和3D打印',
      '物联网施工现场应用',
      '无人机工程监测',
      '智能安全监控系统',
      '数字化交付运维'
    ],
    painPoints: [
      '设计与施工偏差大',
      '现场质量控制困难',
      '进度管理不精准',
      '安全风险监控不足'
    ],
    solutions: [
      '数字孪生偏差分析',
      '智能质量检测系统',
      '物联网进度监控',
      'AI安全风险预警'
    ],
    href: '/smart-construction-new',
    cta: '升级建造技术'
  }
]

// 平台核心价值
const coreValues = [
  {
    icon: <Target className="h-6 w-6" />,
    title: '痛点导向',
    description: '深度分析结构工程师实际工作痛点，提供针对性解决方案'
  },
  {
    icon: <Zap className="h-6 w-6" />,
    title: '技术落地',
    description: '基于现有政策和技术支持，提供可实施的AI/AGENT方案'
  },
  {
    icon: <Users className="h-6 w-6" />,
    title: '个人发展',
    description: '规划结构工程师AI技能提升路径和职业发展通道'
  },
  {
    icon: <Clock className="h-6 w-6" />,
    title: '持续更新',
    description: '每日自动抓取行业动态，保持内容新鲜度和相关性'
  }
]

export default function ProfessionalHomePage() {
  return (
    <>
      <FixedNavigation />
      
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
        {/* 英雄区域 */}
        <div className="container mx-auto px-4 pt-12 pb-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-green-600 to-purple-600 bg-clip-text text-transparent">
              结构工程师AI咨询平台
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">
              聚焦结构工程师专业视角，6大维度深度分析行业痛点，提供可落地的AI/AGENT解决方案
            </p>
            
            <div className="flex flex-wrap justify-center gap-3 mb-12">
              <span className="px-4 py-2 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300 rounded-full font-medium">
                政策前沿
              </span>
              <span className="px-4 py-2 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 rounded-full font-medium">
                行业动态
              </span>
              <span className="px-4 py-2 bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 rounded-full font-medium">
                Agent应用
              </span>
              <span className="px-4 py-2 bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-300 rounded-full font-medium">
                AI技术
              </span>
              <span className="px-4 py-2 bg-teal-100 dark:bg-teal-900 text-teal-800 dark:text-teal-300 rounded-full font-medium">
                智能设计
              </span>
              <span className="px-4 py-2 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-300 rounded-full font-medium">
                智能建造
              </span>
            </div>
          </div>
        </div>

        {/* 6大维度专业展示 */}
        <div className="container mx-auto px-4 pb-12">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold mb-4">🎯 6大专业维度</h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              每个维度深度分析行业痛点，提供具体的AI/AGENT解决方案，基于可落地的政策和技术支持
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {professionalDimensions.map((dimension) => (
              <DimensionCard key={dimension.id} dimension={dimension} />
            ))}
          </div>
        </div>

        {/* 平台核心价值 */}
        <div className="container mx-auto px-4 pb-16">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold mb-4">✨ 平台核心价值</h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              专为结构工程师设计的AI咨询平台，解决实际工作痛点，提供可实施的解决方案
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {coreValues.map((value, index) => (
              <div 
                key={index}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center mb-4">
                  <div className="p-3 bg-gray-100 dark:bg-gray-700 rounded-lg mr-4">
                    {value.icon}
                  </div>
                  <h3 className="text-xl font-semibold">{value.title}</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-400">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* 数据统计 */}
        <div className="bg-gray-50 dark:bg-gray-800 py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">42+</div>
                <div className="text-gray-600 dark:text-gray-400">AI工程应用</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">89+</div>
                <div className="text-gray-600 dark:text-gray-400">Agent案例</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">1568+</div>
                <div className="text-gray-600 dark:text-gray-400">行业数据点</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600 dark:text-orange-400 mb-2">35+</div>
                <div className="text-gray-600 dark:text-gray-400">智能工具</div>
              </div>
            </div>
          </div>
        </div>

        {/* 自动更新提示 */}
        <div className="container mx-auto px-4 py-8">
          <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl p-8 text-center">
            <h3 className="text-2xl font-bold text-white mb-4">
              🔄 每日自动更新系统
            </h3>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              本平台每日自动抓取政策动态、行业资讯、技术突破，保持内容最新鲜、最相关
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <button className="px-6 py-3 bg-white text-blue-600 font-semibold rounded-lg hover:bg-blue-50 transition-colors">
                查看今日更新
              </button>
              <button className="px-6 py-3 bg-transparent border-2 border-white text-white font-semibold rounded-lg hover:bg-white/10 transition-colors">
                订阅更新通知
              </button>
            </div>
          </div>
        </div>

        {/* 页脚 */}
        <footer className="border-t border-gray-200 dark:border-gray-800 py-8">
          <div className="container mx-auto px-4 text-center">
            <p className="text-gray-500 dark:text-gray-400 text-sm">
              结构工程师AI咨询平台 · 6大专业维度 · 每日自动更新
            </p>
            <p className="text-gray-400 dark:text-gray-500 text-xs mt-2">
              最后更新：2026-04-10 00:45 · 框架版本：1.0（6大维度专业化版）
            </p>
          </div>
        </footer>
      </div>
    </>
  )
}