// Next.js服务器预热脚本
const http = require('http');

const urls = [
  'http://localhost:3012/',
  'http://localhost:3012/smart-construction',
  'http://localhost:3012/policy-frontier',
  'http://localhost:3012/industry-frontier'
];

async function warmupServer() {
  console.log(`开始预热服务器 (${new Date().toLocaleString()})`);
  
  for (const url of urls) {
    try {
      const start = Date.now();
      const res = await new Promise((resolve, reject) => {
        http.get(url, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ statusCode: res.statusCode, data }));
        }).on('error', reject);
      });
      const time = Date.now() - start;
      
      console.log(`  ${url}: HTTP ${res.statusCode}, ${time}ms`);
    } catch (error) {
      console.log(`  ${url}: 错误 - ${error.message}`);
    }
    // 短暂延迟避免过载
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  
  console.log(`服务器预热完成 (${new Date().toLocaleString()})`);
}

warmupServer().catch(console.error);
