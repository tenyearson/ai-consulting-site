'use client'

import { useEffect, useState } from 'react'

export default function PlatformDetector() {
  const [isMobile, setIsMobile] = useState(false)
  const [platform, setPlatform] = useState<'unknown' | 'pc' | 'mobile'>('unknown')

  useEffect(() => {
    // 检测用户代理
    const checkPlatform = () => {
      const userAgent = navigator.userAgent.toLowerCase()
      const isMobileDevice = /iphone|ipad|ipod|android|blackberry|windows phone/g.test(userAgent)
      const isTablet = /(ipad|tablet|playbook|silk)|(android(?!.*mobile))/g.test(userAgent)
      
      setIsMobile(isMobileDevice || isTablet)
      setPlatform(isMobileDevice || isTablet ? 'mobile' : 'pc')
      
      // 添加平台类到body
      document.body.classList.remove('platform-pc', 'platform-mobile')
      document.body.classList.add(isMobileDevice || isTablet ? 'platform-mobile' : 'platform-pc')
      
      // 存储到localStorage用于后续请求
      localStorage.setItem('platform', isMobileDevice || isTablet ? 'mobile' : 'pc')
    }

    // 初始检测
    checkPlatform()

    // 监听窗口大小变化（平板可能横屏）
    const handleResize = () => {
      const wasMobile = isMobile
      checkPlatform()
      
      // 如果平台变化，刷新页面以获得最佳布局
      if (wasMobile !== isMobile) {
        window.location.reload()
      }
    }

    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [isMobile])

  // 调试模式下显示平台指示器
  if (process.env.NODE_ENV === 'development') {
    return (
      <div className="platform-indicator">
        {platform === 'mobile' ? '📱 移动端' : '💻 PC端'}
      </div>
    )
  }

  return null
}