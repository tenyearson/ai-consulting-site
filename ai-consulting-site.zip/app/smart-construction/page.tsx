import FixedNavigation from '@/components/FixedNavigation'
import SmartConstructionSection from '@/components/sections/SmartConstructionSection'
import { Building2, Target, TrendingUp, Users, Clock, Download } from 'lucide-react'

export const metadata = {
  title: '智能建造产业应用 - AI咨询平台',
  description: 'AI在实体产业的具体应用和商业价值实现，聚焦材料科学、结构工程、智能建造的深度融合',
}

export default function SmartConstructionPage() {
  return (
    <>
      <FixedNavigation />
      
      <div className="min-h-screen bg-gradient-to-b from-blue-50/30 to-white dark:from-gray-900 dark:to-gray-800">
        {/* 页面头部 */}
        <div className="container mx-auto px-4 pt-8 pb-6">
          <div className="flex items-center mb-6">
            <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-xl mr-4">
              <Building2 className="h-8 w-8 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-blue-700 dark:text-blue-400">
                第一层 · 智能建造产业应用
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-2">
                产业落地 · 工程实践 · 商业价值 · AI在实体产业的具体应用和商业价值实现
              </p>
            </div>
          </div>

          {/* 价值主张卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-blue-200 dark:border-blue-800">
              <div className="flex items-center mb-3">
                <Target className="h-5 w-5 text-blue-500 mr-2" />
                <h3 className="font-semibold">核心价值</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                将AI技术深度融入建筑工程全流程，实现设计、施工、运维的智能化升级
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-blue-200 dark:border-blue-800">
              <div className="flex items-center mb-3">
                <TrendingUp className="h-5 w-5 text-blue-500 mr-2" />
                <h3 className="font-semibold">商业效益</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                平均提升工程效率40-60%，降低人工成本50-70%，质量缺陷率降低80%
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-blue-200 dark:border-blue-800">
              <div className="flex items-center mb-3">
                <Users className="h-5 w-5 text-blue-500 mr-2" />
                <h3 className="font-semibold">适用对象</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                建筑企业、工程公司、设计院、地产开发商、政府基建部门
              </p>
            </div>
          </div>
        </div>

        {/* 最新政策数据区域 */}
        <div className="container mx-auto px-4 py-8">
          <div className="bg-gradient-to-r from-blue-50 to-green-50 dark:from-blue-900/20 dark:to-green-900/20 rounded-2xl p-6 mb-8">
            <div className="flex items-center mb-6">
              <div className="p-3 bg-blue-100 dark:bg-blue-800 rounded-xl mr-4">
                <svg className="h-8 w-8 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-blue-700 dark:text-blue-400">
                  最新政策与行业数据
                </h2>
                <p className="text-gray-600 dark:text-gray-400 mt-1">
                  基于自动更新系统收集的实时数据 • 最后更新: 2026-04-16 08:39
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* 政策数据卡片 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-blue-200 dark:border-blue-800">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <span className="inline-block w-3 h-3 bg-blue-500 rounded-full mr-2"></span>
                  最新智能建造政策
                </h3>
                <div className="space-y-4">
                  <div className="border-l-4 border-blue-500 pl-4 py-2">
                    <h4 className="font-medium text-gray-800 dark:text-gray-200">
                      关于加快推进智能建造与建筑工业化协同发展的指导意见
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      提出到2030年，智能建造与建筑工业化协同发展政策体系和产业体系基本建立
                    </p>
                    <div className="flex items-center mt-2 text-xs text-gray-500">
                      <span>住房和城乡建设部</span>
                      <span className="mx-2">•</span>
                      <span>2026-03-15</span>
                      <a 
                        href="https://www.mohurd.gov.cn/gongkai/zhengce/zhengcefilelib/202603/20260315_772665.html" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="ml-auto bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300 px-2 py-1 rounded hover:bg-blue-200 dark:hover:bg-blue-800 transition-colors"
                      >
                        查看原文
                      </a>
                    </div>
                  </div>
                  
                  <div className="border-l-4 border-green-500 pl-4 py-2">
                    <h4 className="font-medium text-gray-800 dark:text-gray-200">
                      建筑信息模型（BIM）应用统一标准
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      发布BIM技术在工程设计、施工、运维全生命周期的应用标准
                    </p>
                    <div className="flex items-center mt-2 text-xs text-gray-500">
                      <span>住房和城乡建设部</span>
                      <span className="mx-2">•</span>
                      <span>2026-02-28</span>
                      <span className="ml-auto bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 px-2 py-1 rounded">
                        BIM标准
                      </span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    共收集9条最新政策，涵盖智能建造、BIM标准、绿色建筑等领域
                  </p>
                </div>
              </div>

              {/* 行业数据卡片 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-green-200 dark:border-green-800">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <span className="inline-block w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                  行业市场分析
                </h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">市场规模</p>
                      <p className="text-xl font-bold text-gray-800 dark:text-gray-200">8.2万亿元</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-green-600 dark:text-green-400">+12.5%</p>
                      <p className="text-xs text-gray-500">年增长率</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">AI应用渗透率</p>
                      <p className="text-xl font-bold text-gray-800 dark:text-gray-200">34.7%</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-green-600 dark:text-green-400">+8.2%</p>
                      <p className="text-xs text-gray-500">年增长</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">智能建造占比</p>
                      <p className="text-xl font-bold text-gray-800 dark:text-gray-200">15.9%</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-green-600 dark:text-green-400">+5.1%</p>
                      <p className="text-xs text-gray-500">年增长</p>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    基于8条行业数据分析，数据更新时间: 2026-04-16 08:39
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 text-center">
              <button className="inline-flex items-center px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition-colors">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                查看完整数据报告
              </button>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                数据由自动更新系统每小时收集，确保信息时效性
              </p>
            </div>
          </div>
        </div>

        {/* 主要内容区域 */}
        <div className="container mx-auto px-4 pb-12">
          <SmartConstructionSection />
        </div>

        {/* 资源下载区域 */}
        <div className="bg-blue-50 dark:bg-blue-900/20 py-8">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold mb-6 text-center text-blue-700 dark:text-blue-400">
              资源下载与深度阅读
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-blue-200 dark:border-blue-800">
                <div className="flex items-center mb-4">
                  <Download className="h-6 w-6 text-blue-500 mr-3" />
                  <h3 className="text-xl font-semibold">智能建造实施指南</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  完整的智能建造实施路线图，包含技术选型、团队建设、ROI分析、风险控制
                </p>
                <button className="w-full py-3 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition-colors">
                  下载PDF指南 (2.3MB)
                </button>
              </div>
              
              <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-blue-200 dark:border-blue-800">
                <div className="flex items-center mb-4">
                  <Clock className="h-6 w-6 text-blue-500 mr-3" />
                  <h3 className="text-xl font-semibold">案例研究库</h3>
                </div>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  42个真实智能建造案例深度分析，涵盖住宅、商业、基建、工业等不同场景
                </p>
                <button className="w-full py-3 bg-white dark:bg-gray-700 border-2 border-blue-500 text-blue-600 dark:text-blue-400 font-medium rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/30 transition-colors">
                  查看案例库
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 页脚导航 */}
        <footer className="border-t border-gray-200 dark:border-gray-800 py-8">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="mb-4 md:mb-0">
                <div className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
                  AI咨询平台
                </div>
                <p className="text-gray-500 dark:text-gray-400 text-sm mt-2">
                  第一层 · 智能建造产业应用
                </p>
              </div>
              
              <div className="flex space-x-4">
                <a href="/" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400">
                  返回首页
                </a>
                <a href="/vertical-agents" className="text-gray-600 dark:text-gray-400 hover:text-green-600 dark:hover:text-green-400">
                  下一层：Agent应用 →
                </a>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-800 text-center">
              <p className="text-gray-400 dark:text-gray-500 text-sm">
                本页面最后更新：2026-04-08 · 内容基于42个真实产业案例
              </p>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}