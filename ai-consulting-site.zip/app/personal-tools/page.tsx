import FixedNavigation from '@/components/FixedNavigation'
import PersonalAIToolsSection from '@/components/sections/PersonalAIToolsSection'
import { Wrench, Target, Zap, Users, Clock, Download } from 'lucide-react'

export const metadata = {
  title: '个人AI工具链 - AI咨询平台',
  description: '解决"一个人如何高效完成市场调研、内容生产、运营推广、客户转化全流程"的问题，提供立即可用的AI工具推荐',
}

export default function PersonalToolsPage() {
  return (
    <>
      <FixedNavigation />
      
      <div className="min-h-screen bg-gradient-to-b from-orange-50/30 to-white dark:from-gray-900 dark:to-gray-800">
        {/* 页面头部 */}
        <div className="container mx-auto px-4 pt-8 pb-6">
          <div className="flex items-center mb-6">
            <div className="p-3 bg-orange-100 dark:bg-orange-900 rounded-xl mr-4">
              <Wrench className="h-8 w-8 text-orange-600 dark:text-orange-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-orange-700 dark:text-orange-400">
                第三层 · 个人AI工具链
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-2">
                个人赋能 · 效率革命 · 全流程自动化 · 一个人如何高效完成市场调研、内容生产、运营推广、客户转化全流程
              </p>
            </div>
          </div>

          {/* 核心公式展示 */}
          <div className="bg-orange-50 dark:bg-orange-900/30 rounded-xl p-6 mb-8 border border-orange-200 dark:border-orange-800">
            <h3 className="text-xl font-bold mb-4 text-center text-orange-700 dark:text-orange-400">
              🎯 个人创业者成功公式
            </h3>
            <div className="text-center text-2xl font-bold mb-4">
              AI工具链 × 个人专业能力 × 差异化定位 × 持续学习能力
            </div>
            <p className="text-gray-700 dark:text-gray-300 text-center">
              本层重点推荐现有可用AI工具，帮助个人创业者快速构建高效工作流，实现团队级产出
            </p>
          </div>

          {/* 价值主张卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-orange-200 dark:border-orange-800">
              <div className="flex items-center mb-3">
                <Target className="h-5 w-5 text-orange-500 mr-2" />
                <h3 className="font-semibold">解决痛点</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                一个人如何高效完成市场调研、内容生产、运营推广、客户转化全流程
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-orange-200 dark:border-orange-800">
              <div className="flex items-center mb-3">
                <Zap className="h-5 w-5 text-orange-500 mr-2" />
                <h3 className="font-semibold">效率提升</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                使用AI工具链后，个人工作效率平均提升300-500%，实现团队级产出
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-orange-200 dark:border-orange-800">
              <div className="flex items-center mb-3">
                <Users className="h-5 w-5 text-orange-500 mr-2" />
                <h3 className="font-semibold">适用对象</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                个人创业者、自由职业者、小微团队、副业开发者、内容创作者
              </p>
            </div>
          </div>

          {/* 工作流程概览 */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4 text-orange-700 dark:text-orange-400">
              📋 个人创业者全流程工作流
            </h3>
            <div className="space-y-3">
              {[
                '市场调研 → 竞品分析 → 趋势预测',
                '产品设计 → 原型开发 → MVP验证',
                '内容生产 → 文案/设计/视频创作',
                '运营推广 → 社交媒体/邮件/广告',
                '客户转化 → 销售/客服/留存'
              ].map((step, index) => (
                <div key={index} className="flex items-center">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-300 rounded-full text-sm font-bold mr-3">
                    {index + 1}
                  </div>
                  <div className="flex-1 py-3 px-4 bg-white dark:bg-gray-800 rounded-lg border border-orange-200 dark:border-orange-800">
                    {step}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 具体工具推荐和工作流 */}
        <div className="container mx-auto px-4 py-8">
          <div className="bg-gradient-to-r from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20 rounded-2xl p-6 mb-8">
            <div className="flex items-center mb-6">
              <div className="p-3 bg-orange-100 dark:bg-orange-800 rounded-xl mr-4">
                <svg className="h-8 w-8 text-orange-600 dark:text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-orange-700 dark:text-orange-400">
                  具体工具推荐和工作流示例
                </h2>
                <p className="text-gray-600 dark:text-gray-400 mt-1">
                  用户要求：侧重工具推荐而非工作流设计 • 基于89个成功案例提炼
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* 内容创作工作流 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-orange-200 dark:border-orange-800">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <span className="w-3 h-3 bg-orange-500 rounded-full mr-2"></span>
                  内容创作工作流
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-xs font-bold text-orange-600 dark:text-orange-400">1</span>
                    </div>
                    <div>
                      <p className="font-medium">主题研究</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">工具: AnswerThePublic + Google Trends</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-xs font-bold text-orange-600 dark:text-orange-400">2</span>
                    </div>
                    <div>
                      <p className="font-medium">内容生成</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">工具: ChatGPT + Jasper</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-xs font-bold text-orange-600 dark:text-orange-400">3</span>
                    </div>
                    <div>
                      <p className="font-medium">视觉设计</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">工具: Canva + Midjourney</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-xs font-bold text-orange-600 dark:text-orange-400">4</span>
                    </div>
                    <div>
                      <p className="font-medium">发布优化</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">工具: Buffer + Grammarly</p>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    <strong>效率提升:</strong> 传统8小时 → AI辅助2小时 (75%效率提升)
                  </p>
                </div>
              </div>

              {/* 市场调研工作流 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-amber-200 dark:border-amber-800">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <span className="w-3 h-3 bg-amber-500 rounded-full mr-2"></span>
                  市场调研工作流
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-amber-100 dark:bg-amber-900 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-xs font-bold text-amber-600 dark:text-amber-400">1</span>
                    </div>
                    <div>
                      <p className="font-medium">竞品分析</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">工具: Similarweb + SEMrush</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-amber-100 dark:bg-amber-900 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-xs font-bold text-amber-600 dark:text-amber-400">2</span>
                    </div>
                    <div>
                      <p className="font-medium">用户洞察</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">工具: Hotjar + UserTesting</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-amber-100 dark:bg-amber-900 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-xs font-bold text-amber-600 dark:text-amber-400">3</span>
                    </div>
                    <div>
                      <p className="font-medium">趋势预测</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">工具: Google Trends + Exploding Topics</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="w-6 h-6 bg-amber-100 dark:bg-amber-900 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                      <span className="text-xs font-bold text-amber-600 dark:text-amber-400">4</span>
                    </div>
                    <div>
                      <p className="font-medium">报告生成</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">工具: ChatGPT + Beautiful.ai</p>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    <strong>成本节约:</strong> 传统$5,000+ → AI工具$500 (90%成本降低)
                  </p>
                </div>
              </div>
            </div>

            {/* 效率提升数据 */}
            <div className="mt-6 bg-white dark:bg-gray-800 rounded-xl p-5 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold mb-4">实施效果数据</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-3 bg-orange-50 dark:bg-orange-900/30 rounded-lg">
                  <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">75%</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">内容创作效率提升</p>
                </div>
                <div className="text-center p-3 bg-amber-50 dark:bg-amber-900/30 rounded-lg">
                  <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">90%</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">市场调研成本降低</p>
                </div>
                <div className="text-center p-3 bg-orange-50 dark:bg-orange-900/30 rounded-lg">
                  <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">3.2x</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">个人产出倍增</p>
                </div>
                <div className="text-center p-3 bg-amber-50 dark:bg-amber-900/30 rounded-lg">
                  <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">89</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">成功实施案例</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 主要内容区域 */}
        <div className="container mx-auto px-4 pb-12">
          <PersonalAIToolsSection />
        </div>

        {/* 工具组合推荐 */}
        <div className="bg-white dark:bg-gray-800 py-8 border-t border-gray-200 dark:border-gray-700">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold mb-6 text-center text-orange-700 dark:text-orange-400">
              🛠️ 最小可行工具链组合
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6">
                <h3 className="font-semibold mb-4 text-lg">💰 低成本启动组合</h3>
                <ul className="space-y-3 mb-4">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-orange-500 rounded-full mr-3"></span>
                    <span>Google Trends（免费） - 市场调研</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-orange-500 rounded-full mr-3"></span>
                    <span>ChatGPT免费版 - 内容创作</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-orange-500 rounded-full mr-3"></span>
                    <span>Canva免费版 - 设计制作</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-orange-500 rounded-full mr-3"></span>
                    <span>Buffer免费版 - 社交媒体</span>
                  </li>
                </ul>
                <div className="text-orange-600 dark:text-orange-400 font-medium">
                  月成本：$0 · 适合预算有限的创业者
                </div>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6">
                <h3 className="font-semibold mb-4 text-lg">🚀 专业高效组合</h3>
                <ul className="space-y-3 mb-4">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-orange-500 rounded-full mr-3"></span>
                    <span>Similarweb专业版 - 深度分析</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-orange-500 rounded-full mr-3"></span>
                    <span>ChatGPT Plus - 高级创作</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-orange-500 rounded-full mr-3"></span>
                    <span>Canva Pro - 专业设计</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-orange-500 rounded-full mr-3"></span>
                    <span>Mailchimp标准版 - 邮件营销</span>
                  </li>
                </ul>
                <div className="text-orange-600 dark:text-orange-400 font-medium">
                  月成本：~$250 · 适合追求效率的专业人士
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 资源下载区域 */}
        <div className="bg-orange-50 dark:bg-orange-900/20 py-8">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center">
              <h3 className="text-xl font-bold mb-4 text-orange-700 dark:text-orange-400">
                获取个人创业者工具包
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                包含工具对比表、工作流模板、成本计算器、学习资源指南
              </p>
              <button className="px-6 py-3 bg-orange-500 hover:bg-orange-600 text-white font-medium rounded-lg transition-colors flex items-center justify-center mx-auto">
                <Download className="h-5 w-5 mr-2" />
                下载工具包 (35个工具详细评测)
              </button>
            </div>
          </div>
        </div>

        {/* 页脚导航 */}
        <footer className="border-t border-gray-200 dark:border-gray-800 py-8">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="mb-4 md:mb-0">
                <div className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                  AI咨询平台
                </div>
                <p className="text-gray-500 dark:text-gray-400 text-sm mt-2">
                  第三层 · 个人AI工具链 · 效率革命与个人赋能
                </p>
              </div>
              
              <div className="flex space-x-4">
                <a href="/vertical-agents" className="text-gray-600 dark:text-gray-400 hover:text-green-600 dark:hover:text-green-400">
                  ← 上一层：Agent应用
                </a>
                <a href="/ai-frontier" className="text-gray-600 dark:text-gray-400 hover:text-purple-600 dark:hover:text-purple-400">
                  下一层：AI前沿 →
                </a>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-800 text-center">
              <p className="text-gray-400 dark:text-gray-500 text-sm">
                本页面基于35个立即可用AI工具推荐，每月更新工具评测
              </p>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}