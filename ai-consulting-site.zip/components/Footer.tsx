import Link from 'next/link'
import { Github, Twitter, Mail, Rss } from 'lucide-react'

export default function Footer() {
  const currentYear = new Date().getFullYear()
  
  const footerLinks = {
    产品: [
      { name: 'AI资讯', href: '/ai-news' },
      { name: 'Agent应用', href: '/agent-apps' },
      { name: '智能建造', href: '/smart-construction' },
      { name: 'API接口', href: '/api' },
    ],
    资源: [
      { name: '文档', href: '/docs' },
      { name: '教程', href: '/tutorials' },
      { name: '案例研究', href: '/case-studies' },
      { name: '数据源', href: '/data-sources' },
    ],
    支持: [
      { name: '帮助中心', href: '/help' },
      { name: '联系我们', href: '/contact' },
      { name: '反馈建议', href: '/feedback' },
      { name: '服务状态', href: '/status' },
    ],
    法律: [
      { name: '隐私政策', href: '/privacy' },
      { name: '服务条款', href: '/terms' },
      { name: '版权声明', href: '/copyright' },
      { name: '免责声明', href: '/disclaimer' },
    ],
  }

  return (
    <footer className="bg-gray-900 text-gray-300 mt-20">
      <div className="container-responsive py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Logo和描述 */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                <span className="text-white font-bold text-lg">AI</span>
              </div>
              <span className="text-2xl font-bold text-white">智能咨询平台</span>
            </div>
            <p className="text-gray-400 mb-6 max-w-md">
              每日更新AI大模型前沿研究、Agent应用、智能建造领域最新成果。
              致力于提供专业、及时、深度的技术资讯服务。
            </p>
            
            {/* 社交链接 */}
            <div className="flex space-x-4">
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-gray-800 hover:bg-gray-700 transition-colors"
                aria-label="GitHub"
              >
                <Github className="h-5 w-5" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-gray-800 hover:bg-gray-700 transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="h-5 w-5" />
              </a>
              <a
                href="mailto:contact@example.com"
                className="p-2 rounded-full bg-gray-800 hover:bg-gray-700 transition-colors"
                aria-label="Email"
              >
                <Mail className="h-5 w-5" />
              </a>
              <a
                href="/rss.xml"
                className="p-2 rounded-full bg-gray-800 hover:bg-gray-700 transition-colors"
                aria-label="RSS订阅"
              >
                <Rss className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* 链接列 */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="text-white font-semibold mb-4">{category}</h3>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-gray-400 hover:text-white transition-colors text-sm"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* 分隔线 */}
        <div className="border-t border-gray-800 my-8"></div>

        {/* 底部信息 */}
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="text-gray-500 text-sm mb-4 md:mb-0">
            © {currentYear} 智能咨询平台. 保留所有权利.
          </div>
          
          <div className="flex flex-wrap gap-6 text-sm">
            <Link href="/privacy" className="text-gray-500 hover:text-white transition-colors">
              隐私政策
            </Link>
            <Link href="/terms" className="text-gray-500 hover:text-white transition-colors">
              服务条款
            </Link>
            <Link href="/sitemap" className="text-gray-500 hover:text-white transition-colors">
              网站地图
            </Link>
            <div className="text-gray-500">
              最后更新: {new Date().toLocaleDateString('zh-CN')}
            </div>
          </div>
        </div>

        {/* 备案信息（示例） */}
        <div className="mt-6 text-center text-gray-500 text-xs">
          <p>本网站内容仅供参考，不构成任何投资或决策建议。</p>
          <p className="mt-1">数据来源：公开网络，如有侵权请联系删除。</p>
        </div>
      </div>
    </footer>
  )
}