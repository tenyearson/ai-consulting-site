#!/bin/bash
# 自动更新定时任务脚本
# 每日凌晨2点执行政策收集，每周一凌晨3点执行行业数据收集

cd "$(dirname "$0")"
LOG_DIR="/tmp/ai-site-updates"
mkdir -p $LOG_DIR

DATE=$(date +%Y%m%d_%H%M%S)

# 政策数据收集 (每日)
echo "[$(date)] 开始政策数据收集..." >> $LOG_DIR/update_$DATE.log
python3 policy_collector.py >> $LOG_DIR/update_$DATE.log 2>&1
POLICY_RESULT=$?

# 行业数据收集 (仅周一执行)
if [ $(date +%u) -eq 1 ]; then
    echo "[$(date)] 开始行业数据收集..." >> $LOG_DIR/update_$DATE.log
    python3 industry_collector.py >> $LOG_DIR/update_$DATE.log 2>&1
    INDUSTRY_RESULT=$?
else
    INDUSTRY_RESULT=0
    echo "[$(date)] 非周一，跳过行业数据收集" >> $LOG_DIR/update_$DATE.log
fi

# 更新页面显示
if [ $POLICY_RESULT -eq 0 ] || [ $INDUSTRY_RESULT -eq 0 ]; then
    echo "[$(date)] 数据更新成功，最后更新时间: $(date '+%Y-%m-%d %H:%M:%S')" > /tmp/last_update.txt
    echo "✅ 自动更新完成于 $(date '+%Y-%m-%d %H:%M:%S')" >> $LOG_DIR/update_$DATE.log
else
    echo "❌ 自动更新失败，请检查日志" >> $LOG_DIR/update_$DATE.log
fi