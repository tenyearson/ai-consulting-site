'use client'

import { useState } from 'react'
import { Search, FileText, Megaphone, Users, Zap, TrendingUp, DollarSign, Clock, Star, Download } from 'lucide-react'

// 工具分类数据
const toolCategories = [
  {
    id: 1,
    name: '市场调研',
    icon: <Search className="h-6 w-6" />,
    description: '竞品分析、趋势预测、用户洞察',
    problem: '传统调研耗时耗力，数据分散不准确',
    tools: [
      {
        name: 'Similarweb',
        description: '网站流量和竞品分析',
        pricing: '免费版可用，专业版$199/月起',
        features: ['流量分析', '用户行为', '竞品对比', '市场趋势'],
        bestFor: '快速了解市场格局和竞品策略',
        link: 'https://similarweb.com',
        rating: 4.7
      },
      {
        name: 'BuzzSumo',
        description: '内容趋势和影响力分析',
        pricing: '免费试用，专业版$99/月起',
        features: ['热门内容发现', '影响力分析', '内容趋势', '竞品监控'],
        bestFor: '内容营销策略和热点追踪',
        link: 'https://buzzsumo.com',
        rating: 4.5
      },
      {
        name: 'Google Trends',
        description: '搜索趋势和兴趣分析',
        pricing: '完全免费',
        features: ['搜索趋势', '地域分析', '相关查询', '时间趋势'],
        bestFor: '了解用户搜索行为和兴趣变化',
        link: 'https://trends.google.com',
        rating: 4.8
      }
    ]
  },
  {
    id: 2,
    name: '内容生产',
    icon: <FileText className="h-6 w-6" />,
    description: '文案、设计、视频、音频创作',
    problem: '内容创作效率低，质量不稳定',
    tools: [
      {
        name: 'ChatGPT',
        description: 'AI写作和内容生成',
        pricing: '免费版可用，Plus版$20/月',
        features: ['文案写作', '创意构思', '内容优化', '多语言支持'],
        bestFor: '快速生成各种类型的内容草稿',
        link: 'https://chat.openai.com',
        rating: 4.9
      },
      {
        name: 'Canva',
        description: '图形设计和视觉内容',
        pricing: '免费版可用，Pro版$12.99/月',
        features: ['模板设计', '图片编辑', '品牌工具', '协作功能'],
        bestFor: '非设计师快速制作专业级视觉内容',
        link: 'https://canva.com',
        rating: 4.8
      },
      {
        name: 'Descript',
        description: '视频和音频编辑',
        pricing: '免费版可用，专业版$24/月',
        features: ['文字编辑视频', '自动字幕', '音频清理', '屏幕录制'],
        bestFor: '快速编辑播客和视频内容',
        link: 'https://descript.com',
        rating: 4.6
      }
    ]
  },
  {
    id: 3,
    name: '运营推广',
    icon: <Megaphone className="h-6 w-6" />,
    description: '社交媒体、邮件营销、广告投放',
    problem: '多渠道运营复杂，效果难以追踪',
    tools: [
      {
        name: 'Buffer',
        description: '社交媒体管理和调度',
        pricing: '免费版可用，专业版$15/月',
        features: ['多平台发布', '内容日历', '分析报告', '团队协作'],
        bestFor: '统一管理多个社交媒体账号',
        link: 'https://buffer.com',
        rating: 4.5
      },
      {
        name: 'Mailchimp',
        description: '邮件营销自动化',
        pricing: '免费版可用，标准版$13/月',
        features: ['邮件模板', '自动化流程', '受众细分', 'A/B测试'],
        bestFor: '建立和维护邮件营销系统',
        link: 'https://mailchimp.com',
        rating: 4.4
      },
      {
        name: 'Hootsuite',
        description: '社交媒体监控和分析',
        pricing: '专业版$49/月起',
        features: ['社交监听', '竞品监控', '情感分析', '危机预警'],
        bestFor: '品牌声誉管理和社交监听',
        link: 'https://hootsuite.com',
        rating: 4.3
      }
    ]
  },
  {
    id: 4,
    name: '客户转化',
    icon: <Users className="h-6 w-6" />,
    description: '聊天机器人、CRM、个性化推荐',
    problem: '客户转化率低，服务响应慢',
    tools: [
      {
        name: 'Intercom',
        description: '客户沟通和聊天机器人',
        pricing: '起步版$74/月',
        features: ['聊天机器人', '客户支持', '产品导览', '用户分析'],
        bestFor: '自动化客户支持和转化',
        link: 'https://intercom.com',
        rating: 4.6
      },
      {
        name: 'HubSpot CRM',
        description: '客户关系管理',
        pricing: '基础版免费',
        features: ['联系人管理', '交易跟踪', '邮件集成', '报告分析'],
        bestFor: '个人创业者管理客户关系',
        link: 'https://hubspot.com',
        rating: 4.7
      },
      {
        name: 'Calendly',
        description: '预约和会议安排',
        pricing: '免费版可用，专业版$10/月',
        features: ['预约页面', '时区自动', '日历集成', '提醒通知'],
        bestFor: '自动化会议安排和客户预约',
        link: 'https://calendly.com',
        rating: 4.8
      }
    ]
  }
]

// 最小可行工具链
const mvpToolchain = [
  { category: '市场调研', tool: 'Google Trends + Similarweb免费版', cost: '免费', value: '快速了解市场' },
  { category: '内容生产', tool: 'ChatGPT免费版 + Canva免费版', cost: '免费', value: '基础内容创作' },
  { category: '运营推广', tool: 'Buffer免费版 + Mailchimp免费版', cost: '免费', value: '基础营销自动化' },
  { category: '客户转化', tool: 'HubSpot CRM免费版 + Calendly免费版', cost: '免费', value: '客户管理和预约' }
]

export default function PersonalAIToolsSection() {
  const [expandedCategory, setExpandedCategory] = useState<number | null>(1)
  const [selectedTool, setSelectedTool] = useState<string | null>(null)

  const handleCategoryClick = (id: number) => {
    setExpandedCategory(expandedCategory === id ? null : id)
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      {/* 标题和价值主张 */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold flex items-center text-orange-700 dark:text-orange-400">
          <Zap className="mr-3 h-7 w-7" />
          个人AI工具链 · 效率革命
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mt-3 text-lg">
          解决"一个人如何高效完成市场调研、内容生产、运营推广、客户转化全流程"的问题
        </p>
        <div className="mt-4">
          <div className="inline-flex items-center px-4 py-2 bg-orange-100 dark:bg-orange-900 rounded-lg">
            <span className="font-medium text-orange-800 dark:text-orange-300 mr-2">核心公式：</span>
            <span className="text-sm">AI工具链 × 个人专业能力 × 差异化定位 × 持续学习能力</span>
          </div>
        </div>
      </div>

      {/* 核心价值展示 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-orange-50 dark:bg-orange-900/30 p-4 rounded-lg">
          <div className="flex items-center mb-2">
            <Clock className="h-5 w-5 text-orange-500 mr-2" />
            <span className="font-medium">时间节省</span>
          </div>
          <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">60-80%</div>
          <div className="text-sm text-gray-600 dark:text-gray-400">重复性工作时间</div>
        </div>
        <div className="bg-orange-50 dark:bg-orange-900/30 p-4 rounded-lg">
          <div className="flex items-center mb-2">
            <DollarSign className="h-5 w-5 text-orange-500 mr-2" />
            <span className="font-medium">成本降低</span>
          </div>
          <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">70-90%</div>
          <div className="text-sm text-gray-600 dark:text-gray-400">外包和雇佣成本</div>
        </div>
        <div className="bg-orange-50 dark:bg-orange-900/30 p-4 rounded-lg">
          <div className="flex items-center mb-2">
            <TrendingUp className="h-5 w-5 text-orange-500 mr-2" />
            <span className="font-medium">产出提升</span>
          </div>
          <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">3-5倍</div>
          <div className="text-sm text-gray-600 dark:text-gray-400">个人工作效率</div>
        </div>
        <div className="bg-orange-50 dark:bg-orange-900/30 p-4 rounded-lg">
          <div className="flex items-center mb-2">
            <Star className="h-5 w-5 text-orange-500 mr-2" />
            <span className="font-medium">质量提升</span>
          </div>
          <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">40-60%</div>
          <div className="text-sm text-gray-600 dark:text-gray-400">工作成果质量</div>
        </div>
      </div>

      {/* 工具分类 */}
      <div className="space-y-4">
        {toolCategories.map((category) => (
          <div
            key={category.id}
            className={`border rounded-lg overflow-hidden transition-all duration-300 ${
              expandedCategory === category.id
                ? 'border-orange-300 dark:border-orange-700 bg-orange-50 dark:bg-orange-900/20'
                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
            }`}
          >
            {/* 分类头部 */}
            <div 
              className="p-5 cursor-pointer"
              onClick={() => handleCategoryClick(category.id)}
            >
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="p-3 bg-orange-100 dark:bg-orange-900 text-orange-600 dark:text-orange-400 rounded-lg mr-4">
                    {category.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">{category.name}</h3>
                    <p className="text-gray-600 dark:text-gray-400 text-sm mt-1">
                      {category.description}
                    </p>
                  </div>
                </div>
                <div className="text-sm text-gray-500">
                  {expandedCategory === category.id ? '收起工具列表' : '查看推荐工具'}
                </div>
              </div>
              
              {/* 问题描述 */}
              <div className="mt-4 ml-16">
                <div className="text-sm text-gray-700 dark:text-gray-300">
                  <span className="font-medium">解决痛点：</span>
                  {category.problem}
                </div>
              </div>
            </div>

            {/* 展开的工具列表 */}
            {expandedCategory === category.id && (
              <div className="px-5 pb-5 pt-3 border-t border-gray-200 dark:border-gray-700 animate-slide-up">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {category.tools.map((tool, index) => (
                    <div
                      key={index}
                      className={`border rounded-lg p-4 transition-all ${
                        selectedTool === tool.name
                          ? 'border-orange-300 dark:border-orange-700 bg-orange-50 dark:bg-orange-900/20'
                          : 'border-gray-200 dark:border-gray-700 hover:border-orange-200 dark:hover:border-orange-800'
                      }`}
                      onClick={() => setSelectedTool(tool.name)}
                    >
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="font-medium text-gray-900 dark:text-white">
                            {tool.name}
                          </h4>
                          <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                            {tool.description}
                          </div>
                        </div>
                        <div className="flex items-center">
                          <Star className="h-4 w-4 text-yellow-500 mr-1" />
                          <span className="text-sm font-medium">{tool.rating}</span>
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <div className="text-sm font-medium mb-2">主要功能</div>
                        <div className="flex flex-wrap gap-2">
                          {tool.features.map((feature, idx) => (
                            <span key={idx} className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-xs">
                              {feature}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <div className="text-sm font-medium mb-1">最适合</div>
                        <div className="text-sm text-gray-700 dark:text-gray-300">
                          {tool.bestFor}
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <div className="text-sm font-medium text-orange-600 dark:text-orange-400">
                          {tool.pricing}
                        </div>
                        <a
                          href={tool.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
                          onClick={(e) => e.stopPropagation()}
                        >
                          访问官网 →
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* 最小可行工具链 */}
      <div className="mt-8 bg-gradient-to-r from-orange-50 to-yellow-50 dark:from-orange-900/20 dark:to-yellow-900/20 rounded-xl p-6">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <Zap className="h-6 w-6 mr-3 text-orange-500" />
          个人创业者最小可行工具链（零成本启动）
        </h3>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          无需任何投资，使用免费工具即可启动个人创业项目
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {mvpToolchain.map((item, index) => (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-orange-200 dark:border-orange-800">
              <div className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
                {item.category}
              </div>
              <div className="font-medium text-gray-900 dark:text-white mb-2">
                {item.tool}
              </div>
              <div className="flex justify-between items-center">
                <div className="text-sm font-bold text-green-600 dark:text-green-400">
                  {item.cost}
                </div>
                <div className="text-xs text-gray-500">
                  {item.value}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 flex items-center justify-between">
          <div className="text-sm text-gray-600 dark:text-gray-400">
            每月总成本：<span className="font-bold text-green-600 dark:text-green-400">$0</span>
          </div>
          <button className="px-5 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-lg font-medium flex items-center transition-colors">
            <Download className="h-4 w-4 mr-2" />
            下载工具链配置指南
          </button>
        </div>
      </div>

      {/* 实施建议 */}
      <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-bold mb-4">实施建议</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-3">
            <div className="font-medium">阶段一：工具熟悉</div>
            <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>每个类别选择1-2个工具试用</span>
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>完成基础功能学习和配置</span>
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>建立个人工作流程模板</span>
              </li>
            </ul>
          </div>
          <div className="space-y-3">
            <div className="font-medium">阶段二：流程优化</div>
            <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>将工具整合到工作流中</span>
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>建立自动化规则和模板</span>
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>优化工具间的数据流转</span>
              </li>
            </ul>
          </div>
          <div className="space-y-3">
            <div className="font-medium">阶段三：专业升级</div>
            <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>根据需求升级付费版本</span>
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>建立个人品牌和工作系统</span>
              </li>
              <li className="flex items-start">
                <span className="text-orange-500 mr-2">•</span>
                <span>持续学习和工具迭代</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}