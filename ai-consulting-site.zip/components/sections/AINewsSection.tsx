'use client'

import { useState } from 'react'
import { ExternalLink, Calendar, TrendingUp, MessageSquare, BookOpen } from 'lucide-react'

// 模拟AI资讯数据
const mockAINews = [
  {
    id: 1,
    title: 'GPT-5技术细节泄露：多模态能力大幅提升',
    summary: '据泄露信息显示，GPT-5将支持更强大的多模态理解和生成能力，在代码生成和数学推理方面有显著改进。',
    category: '大模型',
    source: 'arXiv',
    date: '2026-04-05',
    readTime: '5分钟',
    hotness: 95,
    originalLink: 'https://arxiv.org/abs/2501.12345',
  },
  {
    id: 2,
    title: 'Google发布Gemini Ultra 2.0：在MMLU基准测试中超越人类专家',
    summary: '最新版本的Gemini Ultra在多项学术基准测试中取得突破性成绩，特别是在数学和科学推理方面。',
    category: '多模态',
    source: 'Google Research',
    date: '2026-04-05',
    readTime: '4分钟',
    hotness: 92,
    originalLink: 'https://ai.google/research',
  },
  {
    id: 3,
    title: 'Meta开源700B参数模型：推动AI民主化',
    summary: 'Meta宣布开源其最大的语言模型，包含7000亿参数，为研究社区提供强大的基础模型。',
    category: '开源',
    source: 'Meta AI',
    date: '2026-04-04',
    readTime: '6分钟',
    hotness: 88,
    originalLink: 'https://ai.meta.com/blog',
  },
  {
    id: 4,
    title: '中国团队发布"悟道3.0"：中文理解能力达到新高度',
    summary: '北京智源研究院发布最新版本的中文大模型，在中文NLP任务上表现优异，特别擅长古文理解和诗歌创作。',
    category: '国产模型',
    source: '智源研究院',
    date: '2026-04-04',
    readTime: '5分钟',
    hotness: 85,
    originalLink: 'https://www.baai.ac.cn',
  },
  {
    id: 5,
    title: 'AI生成视频技术突破：Stable Video Diffusion更新',
    summary: 'Stability AI发布视频生成模型重大更新，支持更长、更稳定的视频生成，质量显著提升。',
    category: '生成式AI',
    source: 'Stability AI',
    date: '2026-04-03',
    readTime: '4分钟',
    hotness: 82,
    originalLink: 'https://stability.ai/news',
  },
]

const categories = ['全部', '大模型', '多模态', '开源', '国产模型', '生成式AI', '强化学习', '边缘AI']

export default function AINewsSection() {
  const [selectedCategory, setSelectedCategory] = useState('全部')
  const [expandedId, setExpandedId] = useState<number | null>(null)

  const filteredNews = selectedCategory === '全部' 
    ? mockAINews 
    : mockAINews.filter(news => news.category === selectedCategory)

  const handleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id)
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      {/* 标题和筛选 */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div className="mb-4 sm:mb-0">
          <h2 className="text-2xl font-bold flex items-center">
            <BookOpen className="mr-3 h-6 w-6 text-blue-500" />
            AI前沿资讯
            <span className="ml-3 text-sm font-normal text-gray-500 dark:text-gray-400">
              每日更新 • 智能筛选
            </span>
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            追踪最新AI研究成果、技术突破和行业动态
          </p>
        </div>
        
        <div className="text-sm text-gray-500">
          <Calendar className="inline h-4 w-4 mr-1" />
          最后更新: 今天 08:00
        </div>
      </div>

      {/* 分类筛选 */}
      <div className="mb-6">
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === category
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* 资讯列表 */}
      <div className="space-y-4">
        {filteredNews.map((news) => (
          <div
            key={news.id}
            className={`border rounded-lg overflow-hidden transition-all duration-300 ${
              expandedId === news.id
                ? 'border-blue-300 dark:border-blue-700 bg-blue-50 dark:bg-blue-900/20'
                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
            }`}
          >
            {/* 资讯头部 */}
            <div 
              className="p-4 cursor-pointer"
              onClick={() => handleExpand(news.id)}
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    <span className="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-xs font-medium">
                      {news.category}
                    </span>
                    <span className="mx-3 text-gray-400">•</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {news.source}
                    </span>
                    <span className="mx-3 text-gray-400">•</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {news.date}
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-semibold mb-2">
                    {news.title}
                  </h3>
                  
                  <p className="text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">
                    {news.summary}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {news.readTime}
                      </span>
                      <span className="flex items-center">
                        <TrendingUp className="h-4 w-4 mr-1" />
                        热度: {news.hotness}%
                      </span>
                    </div>
                    
                    <button className="text-blue-500 hover:text-blue-600 text-sm font-medium">
                      {expandedId === news.id ? '收起详情' : '展开详情'}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* 展开的详情 */}
            {expandedId === news.id && (
              <div className="px-4 pb-4 pt-2 border-t border-gray-200 dark:border-gray-700 animate-slide-up">
                <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4 mb-4">
                  <h4 className="font-medium mb-2 flex items-center">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    详细内容
                  </h4>
                  <p className="text-gray-700 dark:text-gray-300">
                    根据{news.source}发布的最新研究，{news.title.toLowerCase()}。该技术预计将在未来6-12个月内对行业产生重大影响。
                    研究人员表示，这一突破将推动AI在{news.category}领域的应用边界。
                  </p>
                </div>
                
                <div className="flex flex-wrap gap-3">
                  <a
                    href={news.originalLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-sm font-medium transition-colors"
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    查看原文
                  </a>
                  <button className="inline-flex items-center px-4 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-sm font-medium transition-colors">
                    收藏本文
                  </button>
                  <button className="inline-flex items-center px-4 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-sm font-medium transition-colors">
                    分享
                  </button>
                </div>
                
                <div className="mt-4 text-xs text-gray-500">
                  <p>🔍 相关标签: #AI研究 #{news.category} #{news.source.replace(/\s+/g, '')}</p>
                  <p className="mt-1">📊 数据来源: 自动采集于{news.date}，已通过多源验证</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* 底部统计和操作 */}
      <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
        <div className="flex flex-col sm:flex-row justify-between items-center">
          <div className="text-sm text-gray-500 mb-4 sm:mb-0">
            共 {filteredNews.length} 条资讯 • 今日已更新 {mockAINews.filter(n => n.date === '2026-04-05').length} 条
          </div>
          <div className="flex space-x-3">
            <button className="px-4 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-sm font-medium transition-colors">
              加载更多
            </button>
            <button className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-sm font-medium transition-colors">
              订阅更新
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}