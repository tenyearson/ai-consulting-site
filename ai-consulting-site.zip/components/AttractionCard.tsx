'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ChevronRight, ExternalLink, Eye, Clock } from 'lucide-react'

interface AttractionCardProps {
  item: {
    id: number
    title: string
    description: string
    layer: string
    color: string
    icon: React.ReactNode
    stats: string
    image: string
    cta: string
    href: string
  }
}

export default function AttractionCard({ item }: AttractionCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  // 颜色映射
  const colorClasses = {
    blue: {
      bg: 'bg-blue-50 dark:bg-blue-900/20',
      border: 'border-blue-200 dark:border-blue-800',
      text: 'text-blue-700 dark:text-blue-400',
      hover: 'hover:border-blue-300 dark:hover:border-blue-700',
      iconBg: 'bg-blue-100 dark:bg-blue-800',
      iconText: 'text-blue-600 dark:text-blue-300',
      badge: 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300'
    },
    green: {
      bg: 'bg-green-50 dark:bg-green-900/20',
      border: 'border-green-200 dark:border-green-800',
      text: 'text-green-700 dark:text-green-400',
      hover: 'hover:border-green-300 dark:hover:border-green-700',
      iconBg: 'bg-green-100 dark:bg-green-800',
      iconText: 'text-green-600 dark:text-green-300',
      badge: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300'
    },
    orange: {
      bg: 'bg-orange-50 dark:bg-orange-900/20',
      border: 'border-orange-200 dark:border-orange-800',
      text: 'text-orange-700 dark:text-orange-400',
      hover: 'hover:border-orange-300 dark:hover:border-orange-700',
      iconBg: 'bg-orange-100 dark:bg-orange-800',
      iconText: 'text-orange-600 dark:text-orange-300',
      badge: 'bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-300'
    },
    purple: {
      bg: 'bg-purple-50 dark:bg-purple-900/20',
      border: 'border-purple-200 dark:border-purple-800',
      text: 'text-purple-700 dark:text-purple-400',
      hover: 'hover:border-purple-300 dark:hover:border-purple-700',
      iconBg: 'bg-purple-100 dark:bg-purple-800',
      iconText: 'text-purple-600 dark:text-purple-300',
      badge: 'bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300'
    },
    yellow: {
      bg: 'bg-yellow-50 dark:bg-yellow-900/20',
      border: 'border-yellow-200 dark:border-yellow-800',
      text: 'text-yellow-700 dark:text-yellow-400',
      hover: 'hover:border-yellow-300 dark:hover:border-yellow-700',
      iconBg: 'bg-yellow-100 dark:bg-yellow-800',
      iconText: 'text-yellow-600 dark:text-yellow-300',
      badge: 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-300'
    }
  }

  const colors = colorClasses[item.color as keyof typeof colorClasses]

  return (
    <Link href={item.href}>
      <div
        className={`
          relative h-full rounded-xl border-2 p-6 transition-all duration-300
          ${colors.bg} ${colors.border} ${colors.hover}
          ${isHovered ? 'shadow-lg scale-[1.02]' : 'shadow-sm'}
          cursor-pointer overflow-hidden
        `}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* 装饰性背景元素 */}
        <div className={`absolute top-0 right-0 w-32 h-32 opacity-10 ${colors.bg.replace('bg-', 'bg-gradient-to-br from-')}`}></div>
        
        {/* 层标识 */}
        <div className="flex items-center justify-between mb-4">
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${colors.badge}`}>
            {item.layer}
          </span>
          <div className={`p-2 rounded-lg ${colors.iconBg}`}>
            <div className={colors.iconText}>
              {item.icon}
            </div>
          </div>
        </div>

        {/* 标题 */}
        <h3 className={`text-xl font-bold mb-3 ${colors.text}`}>
          {item.title}
        </h3>

        {/* 描述 */}
        <p className="text-gray-600 dark:text-gray-400 mb-6 line-clamp-3">
          {item.description}
        </p>

        {/* 统计数据 */}
        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-6">
          <Eye className="h-4 w-4 mr-1" />
          <span>{item.stats}</span>
          <span className="mx-2">•</span>
          <Clock className="h-4 w-4 mr-1" />
          <span>阅读时间 5-8分钟</span>
        </div>

        {/* 图片占位（实际项目中替换为真实图片） */}
        <div className="mb-6 rounded-lg overflow-hidden">
          <div className={`h-40 ${colors.bg} flex items-center justify-center`}>
            <div className="text-center">
              <div className={`text-4xl mb-2 ${colors.iconText}`}>
                {item.icon}
              </div>
              <div className={`text-sm font-medium ${colors.text}`}>
                {item.layer.split('·')[1].trim()}
              </div>
            </div>
          </div>
        </div>

        {/* 行动按钮 */}
        <div className="flex items-center justify-between">
          <span className={`font-medium ${colors.text} flex items-center`}>
            {item.cta}
            <ChevronRight className={`h-4 w-4 ml-1 transition-transform ${isHovered ? 'translate-x-1' : ''}`} />
          </span>
          
          <div className={`px-3 py-1 rounded-full text-xs font-medium ${colors.badge} flex items-center`}>
            <ExternalLink className="h-3 w-3 mr-1" />
            立即探索
          </div>
        </div>

        {/* 悬停效果指示器 */}
        {isHovered && (
          <div className={`absolute bottom-0 left-0 right-0 h-1 ${colors.bg.replace('bg-', 'bg-gradient-to-r from-')}`}></div>
        )}
      </div>
    </Link>
  )
}