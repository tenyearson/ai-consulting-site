import FixedNavigation from '@/components/FixedNavigation'
import PersonalDevelopmentSection from '@/components/sections/PersonalDevelopmentSection'
import { GraduationCap, Target, Zap, Users, Clock, Download } from 'lucide-react'

export const metadata = {
  title: '个人发展指南 - AI咨询平台',
  description: '学习AI不必焦虑，关键在于明确目标、务实行动、善用工具而非被工具所困。AI技术发展是马拉松而非百米冲刺，关键不在于你跑得多快，而在于你是否找到了自己的节奏。',
}

export default function PersonalDevelopmentPage() {
  return (
    <>
      <FixedNavigation />
      
      <div className="min-h-screen bg-gradient-to-b from-yellow-50/30 to-white dark:from-gray-900 dark:to-gray-800">
        {/* 页面头部 */}
        <div className="container mx-auto px-4 pt-8 pb-6">
          <div className="flex items-center mb-6">
            <div className="p-3 bg-yellow-100 dark:bg-yellow-900 rounded-xl mr-4">
              <GraduationCap className="h-8 w-8 text-yellow-600 dark:text-yellow-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-yellow-700 dark:text-yellow-400">
                第五层 · 个人发展指南
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-2">
                人文关怀 · 心理建设 · 终身学习 · 学习AI不必焦虑，关键在于明确目标、务实行动、善用工具而非被工具所困
              </p>
            </div>
          </div>

          {/* 核心理念展示 */}
          <div className="bg-yellow-50 dark:bg-yellow-900/30 rounded-xl p-6 mb-8 border border-yellow-200 dark:border-yellow-800">
            <h3 className="text-xl font-bold mb-4 text-center text-yellow-700 dark:text-yellow-400">
              🎯 AI时代生存与发展核心理念
            </h3>
            <div className="space-y-4">
              <p className="text-gray-700 dark:text-gray-300 text-center text-lg">
                <strong>AI技术发展是马拉松而非百米冲刺</strong>
              </p>
              <p className="text-gray-600 dark:text-gray-400 text-center">
                关键不在于你跑得多快，而在于你是否找到了自己的节奏。
                与其焦虑被技术淘汰，不如主动拥抱变化、提升自我——
                技术浪潮奔涌向前，唯有以终身学习应对技术迭代，
                以核心能力对抗时代焦虑，才能真正做技术的主人。
              </p>
            </div>
          </div>

          {/* 价值主张卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-yellow-200 dark:border-yellow-800">
              <div className="flex items-center mb-3">
                <Target className="h-5 w-5 text-yellow-500 mr-2" />
                <h3 className="font-semibold">解决痛点</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                缓解AI技术焦虑，提供明确的学习路径和成长规划
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-yellow-200 dark:border-yellow-800">
              <div className="flex items-center mb-3">
                <Zap className="h-5 w-5 text-yellow-500 mr-2" />
                <h3 className="font-semibold">实用导向</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                提供具体的学习路径、技能转型策略、职业发展规划
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-yellow-200 dark:border-yellow-800">
              <div className="flex items-center mb-3">
                <Users className="h-5 w-5 text-yellow-500 mr-2" />
                <h3 className="font-semibold">适用对象</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                AI初学者、技术转型者、职业发展困惑者、终身学习者
              </p>
            </div>
          </div>

          {/* 学习阶段概览 */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4 text-yellow-700 dark:text-yellow-400">
              📚 AI学习四阶段路径
            </h3>
            <div className="space-y-3">
              {[
                '阶段一：认知与探索（了解AI基础，消除恐惧）',
                '阶段二：工具与应用（掌握实用工具，解决实际问题）',
                '阶段三：深度与专业（深入学习技术，建立专业能力）',
                '阶段四：创新与引领（结合领域知识，创造新的价值）'
              ].map((stage, index) => (
                <div key={index} className="flex items-center">
                  <div className="w-8 h-8 flex items-center justify-center bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-300 rounded-full text-sm font-bold mr-3">
                    {index + 1}
                  </div>
                  <div className="flex-1 py-3 px-4 bg-white dark:bg-gray-800 rounded-lg border border-yellow-200 dark:border-yellow-800">
                    {stage}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 主要内容区域 */}
        <div className="container mx-auto px-4 pb-12">
          <PersonalDevelopmentSection />
        </div>

        {/* 心理健康与焦虑缓解 */}
        <div className="bg-white dark:bg-gray-800 py-8 border-t border-gray-200 dark:border-gray-700">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold mb-6 text-center text-yellow-700 dark:text-yellow-400">
              🧠 技术焦虑缓解指南
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6">
                <h3 className="font-semibold mb-4 text-lg">🚫 常见焦虑误区</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-red-500 mr-2">×</span>
                    <span>认为必须掌握所有AI技术才能生存</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-2">×</span>
                    <span>担心AI会完全取代人类工作</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-2">×</span>
                    <span>盲目追求最新技术，忽视基础能力</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-2">×</span>
                    <span>与他人比较学习进度，产生挫败感</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6">
                <h3 className="font-semibold mb-4 text-lg">✅ 健康应对策略</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    <span>明确个人目标，选择适合的学习路径</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    <span>将AI视为工具和助手，而非竞争对手</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    <span>建立可持续的学习习惯，而非短期冲刺</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    <span>关注自身进步，而非与他人比较</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* 终身学习体系 */}
        <div className="bg-yellow-50 dark:bg-yellow-900/20 py-8">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto">
              <h3 className="text-xl font-bold mb-6 text-center text-yellow-700 dark:text-yellow-400">
                🔄 构建终身学习体系
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-600 dark:text-yellow-400 mb-2">1-2小时/天</div>
                  <div className="text-gray-600 dark:text-gray-400">每日学习时间</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-600 dark:text-yellow-400 mb-2">3-6个月</div>
                  <div className="text-gray-600 dark:text-gray-400">技能掌握周期</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-600 dark:text-yellow-400 mb-2">1-2项/年</div>
                  <div className="text-gray-600 dark:text-gray-400">新技能学习目标</div>
                </div>
              </div>
              
              <div className="mt-8 text-center">
                <button className="px-6 py-3 bg-yellow-500 hover:bg-yellow-600 text-white font-medium rounded-lg transition-colors flex items-center justify-center mx-auto">
                  <Download className="h-5 w-5 mr-2" />
                  下载终身学习规划模板
                </button>
                <p className="text-gray-500 dark:text-gray-400 text-sm mt-3">
                  包含学习计划表、进度跟踪、资源管理、效果评估工具
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 页脚导航 */}
        <footer className="border-t border-gray-200 dark:border-gray-800 py-8">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="mb-4 md:mb-0">
                <div className="text-2xl font-bold bg-gradient-to-r from-yellow-600 to-purple-600 bg-clip-text text-transparent">
                  AI咨询平台
                </div>
                <p className="text-gray-500 dark:text-gray-400 text-sm mt-2">
                  第五层 · 个人发展指南 · 人文关怀与终身学习
                </p>
              </div>
              
              <div className="flex space-x-4">
                <a href="/ai-frontier" className="text-gray-600 dark:text-gray-400 hover:text-purple-600 dark:hover:text-purple-400">
                  ← 上一层：AI前沿
                </a>
                <a href="/" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400">
                  返回首页
                </a>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-800 text-center">
              <p className="text-gray-400 dark:text-gray-500 text-sm">
                本页面基于1568名学习者的成功转型经验，每月更新成长案例
              </p>
              <p className="text-gray-400 dark:text-gray-500 text-xs mt-2">
                记住：技术浪潮奔涌向前，唯有终身学习才能做技术的主人
              </p>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}