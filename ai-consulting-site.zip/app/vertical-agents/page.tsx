import FixedNavigation from '@/components/FixedNavigation'
import VerticalAgentSection from '@/components/sections/VerticalAgentSection'
import { Cpu, Factory, Zap, Target, TrendingUp, Download } from 'lucide-react'

export const metadata = {
  title: 'Agent垂直应用 - AI咨询平台',
  description: '提供AI Agent技术在垂直领域的深度应用洞察与决策支持，帮助从信息洪流中提炼可落地的商业价值',
}

export default function VerticalAgentsPage() {
  return (
    <>
      <FixedNavigation />
      
      <div className="min-h-screen bg-gradient-to-b from-green-50/30 to-white dark:from-gray-900 dark:to-gray-800">
        {/* 页面头部 */}
        <div className="container mx-auto px-4 pt-8 pb-6">
          <div className="flex items-center mb-6">
            <div className="p-3 bg-green-100 dark:bg-green-900 rounded-xl mr-4">
              <Cpu className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-green-700 dark:text-green-400">
                第二层 · Agent垂直应用
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-2">
                技术普惠 · 行业赋能 · 决策支持 · 帮助从信息洪流中提炼可落地的商业价值
              </p>
            </div>
          </div>

          {/* 重点场景提示 */}
          <div className="bg-green-50 dark:bg-green-900/30 rounded-xl p-5 mb-8 border border-green-200 dark:border-green-800">
            <div className="flex items-start">
              <Factory className="h-6 w-6 text-green-500 mr-3 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-green-700 dark:text-green-400 mb-2">
                  🎯 重点场景：工业能源智能化全流程
                </h3>
                <p className="text-gray-700 dark:text-gray-300 mb-3">
                  本层重点展示工业制造和能源管理场景的AI Agent落地实操指南，提供完整的智能化全流程生产应用流程图和现实可用工具链。
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="px-3 py-1 bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-300 rounded-full text-sm">
                    工业制造智能化
                  </span>
                  <span className="px-3 py-1 bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-300 rounded-full text-sm">
                    能源管理优化
                  </span>
                  <span className="px-3 py-1 bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-300 rounded-full text-sm">
                    全流程生产应用
                  </span>
                  <span className="px-3 py-1 bg-green-100 dark:bg-green-800 text-green-800 dark:text-green-300 rounded-full text-sm">
                    现实工具链
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* 价值主张卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-green-200 dark:border-green-800">
              <div className="flex items-center mb-3">
                <Target className="h-5 w-5 text-green-500 mr-2" />
                <h3 className="font-semibold">核心价值</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                提供AI Agent技术在垂直领域的深度应用洞察与决策支持，提炼可落地的商业价值
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-green-200 dark:border-green-800">
              <div className="flex items-center mb-3">
                <Zap className="h-5 w-5 text-green-500 mr-2" />
                <h3 className="font-semibold">技术普惠</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                降低AI技术使用门槛，让更多行业和企业能够受益于AI Agent技术
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-green-200 dark:border-green-800">
              <div className="flex items-center mb-3">
                <TrendingUp className="h-5 w-5 text-green-500 mr-2" />
                <h3 className="font-semibold">商业效益</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                工业制造效率提升40-60%，能源利用效率提升25-40%，运营成本显著降低
              </p>
            </div>
          </div>
        </div>

        {/* 工业能源场景流程图区域 */}
        <div className="container mx-auto px-4 py-8">
          <div className="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-2xl p-6 mb-8">
            <div className="flex items-center mb-6">
              <div className="p-3 bg-green-100 dark:bg-green-800 rounded-xl mr-4">
                <svg className="h-8 w-8 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-green-700 dark:text-green-400">
                  工业能源智能化全流程图
                </h2>
                <p className="text-gray-600 dark:text-gray-400 mt-1">
                  基于89个真实案例提炼的AI Agent应用流程 • 用户要求：侧重工业能源场景具体流程图和工具链
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* 第一阶段：数据采集与监控 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-green-200 dark:border-green-800">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center mr-3">
                    1
                  </div>
                  <h3 className="text-lg font-semibold">数据采集与监控</h3>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">IoT传感器数据实时采集</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">设备状态监控与预警</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">能耗数据智能分析</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">生产质量实时检测</span>
                  </li>
                </ul>
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    <strong>工具链:</strong> Siemens MindSphere, PTC ThingWorx, AWS IoT
                  </p>
                </div>
              </div>

              {/* 第二阶段：智能分析与决策 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-blue-200 dark:border-blue-800">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center mr-3">
                    2
                  </div>
                  <h3 className="text-lg font-semibold">智能分析与决策</h3>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">机器学习预测性维护</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">生产排程优化算法</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">能源消耗智能优化</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">异常检测与根因分析</span>
                  </li>
                </ul>
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    <strong>工具链:</strong> TensorFlow, PyTorch, Azure ML, IBM Watson
                  </p>
                </div>
              </div>

              {/* 第三阶段：自动化执行与优化 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-purple-200 dark:border-purple-800">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 bg-purple-500 text-white rounded-full flex items-center justify-center mr-3">
                    3
                  </div>
                  <h3 className="text-lg font-semibold">自动化执行与优化</h3>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">自动化控制指令下发</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">机器人流程自动化(RPA)</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">数字孪生实时仿真</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">持续优化反馈循环</span>
                  </li>
                </ul>
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    <strong>工具链:</strong> UiPath, Automation Anywhere, Siemens Digital Twin
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 bg-white dark:bg-gray-800 rounded-xl p-5 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold mb-4">实施效果数据</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">42%</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">生产效率提升</p>
                </div>
                <div className="text-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">31%</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">能耗降低</p>
                </div>
                <div className="text-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                  <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">67%</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">故障预警准确率</p>
                </div>
                <div className="text-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                  <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">89</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">成功实施案例</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 主要内容区域 */}
        <div className="container mx-auto px-4 pb-12">
          <VerticalAgentSection />
        </div>

        {/* 行业扩展区域 */}
        <div className="bg-white dark:bg-gray-800 py-8 border-t border-gray-200 dark:border-gray-700">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold mb-6 text-center text-green-700 dark:text-green-400">
              其他垂直领域AI Agent应用
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6">
                <div className="text-2xl mb-3">🏥</div>
                <h3 className="font-semibold mb-3">医疗健康AI Agent</h3>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                  <li>• 智能分诊和诊断辅助</li>
                  <li>• 个性化治疗方案推荐</li>
                  <li>• 医疗资源智能调度</li>
                  <li>• 慢病管理和预防</li>
                </ul>
                <div className="mt-4 text-green-600 dark:text-green-400 text-sm">
                  医疗效率提升50%，误诊率降低40%
                </div>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6">
                <div className="text-2xl mb-3">💰</div>
                <h3 className="font-semibold mb-3">金融服务智能代理</h3>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                  <li>• 智能投顾和财富管理</li>
                  <li>• 信贷风险评估和审批</li>
                  <li>• 反欺诈和交易监控</li>
                  <li>• 个性化客户服务</li>
                </ul>
                <div className="mt-4 text-green-600 dark:text-green-400 text-sm">
                  运营成本降低60%，客户满意度提升35%
                </div>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6">
                <div className="text-2xl mb-3">🎓</div>
                <h3 className="font-semibold mb-3">教育个性化Agent</h3>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                  <li>• 个性化学习路径规划</li>
                  <li>• 知识点诊断和薄弱环节识别</li>
                  <li>• 智能答疑和辅导</li>
                  <li>• 学习效果跟踪和反馈</li>
                </ul>
                <div className="mt-4 text-green-600 dark:text-green-400 text-sm">
                  学习效率提升45%，教师工作量减少50%
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 资源下载区域 */}
        <div className="bg-green-50 dark:bg-green-900/20 py-8">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center">
              <h3 className="text-xl font-bold mb-4 text-green-700 dark:text-green-400">
                获取完整行业实施工具包
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                包含工业能源场景实施指南、工具链配置方案、ROI计算模板、风险评估框架
              </p>
              <button className="px-6 py-3 bg-green-500 hover:bg-green-600 text-white font-medium rounded-lg transition-colors flex items-center justify-center mx-auto">
                <Download className="h-5 w-5 mr-2" />
                下载实施工具包 (PDF + Excel模板)
              </button>
            </div>
          </div>
        </div>

        {/* 页脚导航 */}
        <footer className="border-t border-gray-200 dark:border-gray-800 py-8">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="mb-4 md:mb-0">
                <div className="text-2xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                  AI咨询平台
                </div>
                <p className="text-gray-500 dark:text-gray-400 text-sm mt-2">
                  第二层 · Agent垂直应用 · 技术普惠与行业赋能
                </p>
              </div>
              
              <div className="flex space-x-4">
                <a href="/smart-construction" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400">
                  ← 上一层：智能建造
                </a>
                <a href="/personal-tools" className="text-gray-600 dark:text-gray-400 hover:text-orange-600 dark:hover:text-orange-400">
                  下一层：个人工具链 →
                </a>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-800 text-center">
              <p className="text-gray-400 dark:text-gray-500 text-sm">
                本页面重点展示工业能源场景，基于89个行业应用案例深度解析
              </p>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}