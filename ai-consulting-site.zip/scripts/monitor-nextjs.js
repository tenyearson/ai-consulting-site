// Next.js服务器监控和自动重启脚本
const { exec } = require('child_process');
const fs = require('fs');

const MAX_RUNTIME_HOURS = 8; // 最大运行时间8小时
const CHECK_INTERVAL_MINUTES = 30; // 检查间隔30分钟
const LOG_FILE = '/tmp/nextjs_monitor.log';

function log(message) {
  const timestamp = new Date().toLocaleString();
  const logMessage = `[${timestamp}] ${message}\n`;
  console.log(logMessage.trim());
  fs.appendFileSync(LOG_FILE, logMessage);
}

function checkServerStatus() {
  return new Promise((resolve) => {
    exec('curl -s -o /dev/null -w "%{http_code}" http://localhost:3012/', (error, stdout) => {
      if (error || stdout.trim() !== '200') {
        resolve({ status: 'down', code: stdout.trim() });
      } else {
        // 检查进程运行时间
        exec('ps aux | grep "next-server" | grep -v grep', (err, output) => {
          if (err || !output) {
            resolve({ status: 'unknown' });
          } else {
            const lines = output.trim().split('\n');
            if (lines.length > 0) {
              const pid = lines[0].split(/\s+/)[1];
              exec(`ps -o etime= -p ${pid}`, (etimeErr, etimeOutput) => {
                if (etimeErr) {
                  resolve({ status: 'up', runtime: 'unknown' });
                } else {
                  resolve({ status: 'up', runtime: etimeOutput.trim() });
                }
              });
            } else {
              resolve({ status: 'down' });
            }
          }
        });
      }
    });
  });
}

function restartServer() {
  log('开始重启Next.js服务器...');
  return new Promise((resolve) => {
    exec('pkill -f "next-server\|next dev"', () => {
      setTimeout(() => {
        exec('cd /home/openclawdj/projects/ai-consulting-site && PORT=3012 npm run dev > /tmp/nextjs_auto_restart.log 2>&1 &', (err) => {
          if (err) {
            log(`重启失败: ${err.message}`);
            resolve(false);
          } else {
            log('服务器重启命令已发送，等待启动...');
            // 等待启动
            setTimeout(() => {
              checkServerStatus().then(status => {
                if (status.status === 'up') {
                  log(`服务器重启成功，运行时间: ${status.runtime || '新进程'}`);
                  resolve(true);
                } else {
                  log('服务器重启后状态检查失败');
                  resolve(false);
                }
              });
            }, 15000);
          }
        });
      }, 2000);
    });
  });
}

function parseRuntime(runtimeStr) {
  if (!runtimeStr) return 0;
  
  // 格式: [[dd-]hh:]mm:ss
  const parts = runtimeStr.split(':');
  if (parts.length === 3) {
    // 有天数部分 dd-hh:mm:ss
    const dayHour = parts[0].split('-');
    if (dayHour.length === 2) {
      const days = parseInt(dayHour[0]) || 0;
      const hours = parseInt(dayHour[1]) || 0;
      const minutes = parseInt(parts[1]) || 0;
      return days * 24 + hours + minutes / 60;
    } else {
      // hh:mm:ss
      const hours = parseInt(parts[0]) || 0;
      const minutes = parseInt(parts[1]) || 0;
      return hours + minutes / 60;
    }
  } else if (parts.length === 2) {
    // mm:ss
    const minutes = parseInt(parts[0]) || 0;
    return minutes / 60;
  }
  return 0;
}

async function monitorLoop() {
  log('Next.js服务器监控启动');
  
  while (true) {
    try {
      const status = await checkServerStatus();
      
      if (status.status === 'down') {
        log(`服务器状态: 宕机 (HTTP ${status.code})，尝试重启...`);
        const restartSuccess = await restartServer();
        if (!restartSuccess) {
          log('重启失败，将在下次检查时重试');
        }
      } else if (status.status === 'up') {
        const runtimeHours = parseRuntime(status.runtime);
        if (runtimeHours >= MAX_RUNTIME_HOURS) {
          log(`服务器运行时间: ${runtimeHours.toFixed(2)}小时，超过${MAX_RUNTIME_HOURS}小时阈值，执行预防性重启...`);
          await restartServer();
        } else {
          log(`服务器状态: 运行正常，运行时间: ${status.runtime} (${runtimeHours.toFixed(2)}小时)`);
        }
      } else {
        log('服务器状态: 未知');
      }
    } catch (error) {
      log(`监控检查错误: ${error.message}`);
    }
    
    // 等待下次检查
    await new Promise(resolve => setTimeout(resolve, CHECK_INTERVAL_MINUTES * 60 * 1000));
  }
}

// 启动监控
monitorLoop().catch(error => {
  log(`监控主循环错误: ${error.message}`);
  process.exit(1);
});
