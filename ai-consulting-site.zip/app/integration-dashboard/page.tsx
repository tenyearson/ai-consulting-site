export default function IntegrationDashboard() {
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">数据集成仪表板</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">数据文件状态</h2>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span>政策数据文件</span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">已加载</span>
            </div>
            <div className="flex justify-between items-center">
              <span>行业报告文件</span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">已加载</span>
            </div>
            <div className="flex justify-between items-center">
              <span>数据更新时间</span>
              <span className="text-gray-600">2026-04-16</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">页面集成状态</h2>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span>智能建造页面</span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">已集成</span>
            </div>
            <div className="flex justify-between items-center">
              <span>政策页面</span>
              <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm">待创建</span>
            </div>
            <div className="flex justify-between items-center">
              <span>行业页面</span>
              <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm">待创建</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">性能状态</h2>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span>首页响应时间</span>
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">46ms</span>
            </div>
            <div className="flex justify-between items-center">
              <span>智能建造页面</span>
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">48ms</span>
            </div>
            <div className="flex justify-between items-center">
              <span>服务器状态</span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">运行中</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">数据预览</h2>
          <div className="space-y-3">
            <div className="text-sm text-gray-600">
              <p>最新政策数据日期: 2026-04-16</p>
              <p>行业报告生成时间: 2026-04-16 08:39</p>
              <p>数据文件数量: 4个JSON文件</p>
            </div>
            <div className="pt-4">
              <a href="/smart-construction" className="text-blue-600 hover:text-blue-800">
                查看智能建造页面集成效果 →
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 p-6 bg-gray-50 rounded-lg">
        <h2 className="text-xl font-semibold mb-4">集成检查说明</h2>
        <ul className="list-disc pl-5 space-y-2 text-gray-700">
          <li>此页面用于检查AI网页资讯任务的数据集成效果</li>
          <li>智能建造页面已确认集成2026-04-16政策数据</li>
          <li>政策数据和行业报告文件已加载并可访问</li>
          <li>服务器性能优化完成，响应时间稳定在46-48ms</li>
          <li>缺失的政策和行业页面需要创建以完善内容建设</li>
        </ul>
      </div>
    </div>
  );
}