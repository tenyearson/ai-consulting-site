const fs = require('fs');
const path = require('path');

function getLastUpdateTime() {
  const files = [
    'policies_latest.json',
    'industry_report_20260416_083913.json',
    'industry_report_20260411_123822.json'
  ];
  
  let latestTime = null;
  
  for (const file of files) {
    try {
      const filePath = path.join(__dirname, '..', file);
      if (fs.existsSync(filePath)) {
        const stats = fs.statSync(filePath);
        if (!latestTime || stats.mtime > latestTime) {
          latestTime = stats.mtime;
        }
      }
    } catch (error) {
      console.error(`Error checking file ${file}:`, error.message);
    }
  }
  
  return latestTime ? latestTime.toISOString().split('T')[0] + ' ' + 
         latestTime.toISOString().split('T')[1].substring(0, 8) : '2026-04-11 12:37';
}

// 测试输出
console.log('最后更新时间:', getLastUpdateTime());
