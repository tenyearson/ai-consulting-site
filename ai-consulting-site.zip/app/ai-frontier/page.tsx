import FixedNavigation from '@/components/FixedNavigation'
import AIFrontierSection from '@/components/sections/AIFrontierSection'
import { Newspaper, Target, Zap, TrendingUp, Download, Clock } from 'lucide-react'

export const metadata = {
  title: 'AI前沿资讯 - AI咨询平台',
  description: '追踪最新AI研究成果、技术突破和行业动态，保持技术前沿敏感度，了解大模型、多模态、开源生态、硬件算力最新进展',
}

export default function AIFrontierPage() {
  return (
    <>
      <FixedNavigation />
      
      <div className="min-h-screen bg-gradient-to-b from-purple-50/30 to-white dark:from-gray-900 dark:to-gray-800">
        {/* 页面头部 */}
        <div className="container mx-auto px-4 pt-8 pb-6">
          <div className="flex items-center mb-6">
            <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-xl mr-4">
              <Newspaper className="h-8 w-8 text-purple-600 dark:text-purple-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-purple-700 dark:text-purple-400">
                第四层 · AI前沿资讯
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-2">
                技术追踪 · 趋势洞察 · 行业动态 · 追踪最新AI研究成果、技术突破和行业动态，保持技术前沿敏感度
              </p>
            </div>
          </div>

          {/* 更新频率提示 */}
          <div className="bg-purple-50 dark:bg-purple-900/30 rounded-xl p-5 mb-8 border border-purple-200 dark:border-purple-800">
            <div className="flex items-center">
              <Clock className="h-6 w-6 text-purple-500 mr-3 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-purple-700 dark:text-purple-400 mb-2">
                  📈 每日更新28+条前沿资讯
                </h3>
                <p className="text-gray-700 dark:text-gray-300">
                  本层内容每日更新，涵盖大模型技术突破、多模态AI进展、开源模型生态、硬件算力发展、行业应用动态等关键领域。
                </p>
              </div>
            </div>
          </div>

          {/* 价值主张卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-purple-200 dark:border-purple-800">
              <div className="flex items-center mb-3">
                <Target className="h-5 w-5 text-purple-500 mr-2" />
                <h3 className="font-semibold">核心价值</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                帮助从业者保持技术前沿敏感度，避免信息滞后，把握技术发展趋势
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-purple-200 dark:border-purple-800">
              <div className="flex items-center mb-3">
                <Zap className="h-5 w-5 text-purple-500 mr-2" />
                <h3 className="font-semibold">信息筛选</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                从海量AI资讯中筛选最有价值的内容，节省信息筛选时间，聚焦关键突破
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-purple-200 dark:border-purple-800">
              <div className="flex items-center mb-3">
                <TrendingUp className="h-5 w-5 text-purple-500 mr-2" />
                <h3 className="font-semibold">趋势预测</h3>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                基于技术发展轨迹进行趋势分析，帮助预判未来1-2年技术发展方向
              </p>
            </div>
          </div>

          {/* 重点关注领域 */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4 text-purple-700 dark:text-purple-400">
              🎯 重点关注领域
            </h3>
            <div className="flex flex-wrap gap-2">
              {[
                '大模型技术突破',
                '多模态AI进展', 
                '开源模型生态',
                '硬件算力发展',
                '行业应用动态',
                '政策法规更新',
                '学术研究前沿',
                '商业落地案例'
              ].map((topic, index) => (
                <span key={index} className="px-3 py-2 bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300 rounded-lg text-sm">
                  {topic}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* 前沿技术趋势区域 */}
        <div className="container mx-auto px-4 py-8">
          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 rounded-2xl p-6 mb-8">
            <div className="flex items-center mb-6">
              <div className="p-3 bg-purple-100 dark:bg-purple-800 rounded-xl mr-4">
                <svg className="h-8 w-8 text-purple-600 dark:text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-purple-700 dark:text-purple-400">
                  前沿技术趋势追踪
                </h2>
                <p className="text-gray-600 dark:text-gray-400 mt-1">
                  每日更新28+条前沿资讯 • 基于156个权威源自动收集分析
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* 大模型技术突破 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-purple-200 dark:border-purple-800">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 bg-purple-500 text-white rounded-full flex items-center justify-center mr-3">
                    <span className="text-sm font-bold">LLM</span>
                  </div>
                  <h3 className="text-lg font-semibold">大模型技术突破</h3>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">上下文长度扩展至1M+ tokens</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">推理速度优化300%+</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">多模态统一架构成熟</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">开源模型性能接近GPT-4</span>
                  </li>
                </ul>
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    <strong>关键进展:</strong> DeepSeek-V3, Qwen2.5, Llama 3.1
                  </p>
                </div>
              </div>

              {/* 多模态AI进展 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-indigo-200 dark:border-indigo-800">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 bg-indigo-500 text-white rounded-full flex items-center justify-center mr-3">
                    <span className="text-sm font-bold">MM</span>
                  </div>
                  <h3 className="text-lg font-semibold">多模态AI进展</h3>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">视频理解准确率95%+</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">3D场景生成商业化</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">音频情感识别突破</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">跨模态检索实时化</span>
                  </li>
                </ul>
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    <strong>关键进展:</strong> Sora, Gen-3, Stable Video
                  </p>
                </div>
              </div>

              {/* 硬件算力发展 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-violet-200 dark:border-violet-800">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 bg-violet-500 text-white rounded-full flex items-center justify-center mr-3">
                    <span className="text-sm font-bold">HW</span>
                  </div>
                  <h3 className="text-lg font-semibold">硬件算力发展</h3>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-violet-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">AI芯片能效比提升5x</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-violet-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">边缘AI设备普及</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-violet-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">量子计算AI应用实验</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-2 h-2 bg-violet-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">内存计算技术突破</span>
                  </li>
                </ul>
                <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    <strong>关键进展:</strong> NVIDIA Blackwell, Groq LPU, Cerebras
                  </p>
                </div>
              </div>
            </div>

            {/* 行业应用动态 */}
            <div className="mt-6 bg-white dark:bg-gray-800 rounded-xl p-5 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold mb-4">行业应用动态</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/30 rounded-lg">
                  <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">42%</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">企业已部署AI</p>
                </div>
                <div className="text-center p-3 bg-indigo-50 dark:bg-indigo-900/30 rounded-lg">
                  <p className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">$2.3T</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">2026年AI市场规模</p>
                </div>
                <div className="text-center p-3 bg-violet-50 dark:bg-violet-900/30 rounded-lg">
                  <p className="text-2xl font-bold text-violet-600 dark:text-violet-400">156</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">每日资讯源</p>
                </div>
                <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/30 rounded-lg">
                  <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">28+</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">每日更新条目</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 主要内容区域 */}
        <div className="container mx-auto px-4 pb-12">
          <AIFrontierSection />
        </div>

        {/* 技术趋势分析 */}
        <div className="bg-white dark:bg-gray-800 py-8 border-t border-gray-200 dark:border-gray-700">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold mb-6 text-center text-purple-700 dark:text-purple-400">
              📊 2026年AI技术趋势预测
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6">
                <h3 className="font-semibold mb-4 text-lg">🚀 确定性趋势</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></span>
                    <span>多模态AI成为标配，文本+图像+视频+音频融合</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></span>
                    <span>开源模型性能接近闭源，成本大幅下降</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></span>
                    <span>边缘AI设备普及，本地化AI应用增多</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></span>
                    <span>AI Agent自动化程度提升，自主执行复杂任务</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6">
                <h3 className="font-semibold mb-4 text-lg">🔮 潜在突破点</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></span>
                    <span>AI在科学发现中的应用（药物研发、材料科学）</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></span>
                    <span>神经符号AI结合，提升推理和解释能力</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></span>
                    <span>AI硬件专用芯片性能突破，能效比提升</span>
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-purple-500 rounded-full mr-3 mt-2"></span>
                    <span>具身AI和机器人技术融合进展</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* 订阅区域 */}
        <div className="bg-purple-50 dark:bg-purple-900/20 py-8">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center">
              <h3 className="text-xl font-bold mb-4 text-purple-700 dark:text-purple-400">
                订阅AI前沿周报
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                每周精选最重要的AI技术突破、行业动态、投资趋势，直接发送到您的邮箱
              </p>
              <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                <input 
                  type="email" 
                  placeholder="输入您的邮箱地址"
                  className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800"
                />
                <button className="px-6 py-3 bg-purple-500 hover:bg-purple-600 text-white font-medium rounded-lg transition-colors">
                  免费订阅
                </button>
              </div>
              <p className="text-gray-500 dark:text-gray-400 text-sm mt-4">
                每周一早上发送，随时可退订，保护您的隐私
              </p>
            </div>
          </div>
        </div>

        {/* 页脚导航 */}
        <footer className="border-t border-gray-200 dark:border-gray-800 py-8">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="mb-4 md:mb-0">
                <div className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-orange-600 bg-clip-text text-transparent">
                  AI咨询平台
                </div>
                <p className="text-gray-500 dark:text-gray-400 text-sm mt-2">
                  第四层 · AI前沿资讯 · 技术追踪与趋势洞察
                </p>
              </div>
              
              <div className="flex space-x-4">
                <a href="/personal-tools" className="text-gray-600 dark:text-gray-400 hover:text-orange-600 dark:hover:text-orange-400">
                  ← 上一层：个人工具链
                </a>
                <a href="/personal-development" className="text-gray-600 dark:text-gray-400 hover:text-yellow-600 dark:hover:text-yellow-400">
                  下一层：个人指南 →
                </a>
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-800 text-center">
              <p className="text-gray-400 dark:text-gray-500 text-sm">
                本页面每日更新，基于1568+条AI前沿资讯深度分析
              </p>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}