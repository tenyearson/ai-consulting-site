'use client'

import { useState, useEffect } from 'react'
import { 
  Building2, TrendingUp, Cpu, CpuIcon, DraftingCompass, Construction,
  Target, Zap, Users, Clock, Download, ChevronRight, AlertCircle, 
  CheckCircle, Menu, X, Smartphone, Globe, RefreshCw, ExternalLink
} from 'lucide-react'

// 6大维度数据
const professionalDimensions = [
  {
    id: 1,
    title: '行业政策前沿',
    subtitle: '政策解读 · 标准更新 · 补贴申请',
    description: '跟踪建筑行业最新政策法规、标准规范、监管要求、补贴政策',
    icon: <Building2 className="h-6 w-6" />,
    color: 'blue',
    stats: '每日更新政策动态',
    features: ['智能建造政策支持', 'BIM强制应用进展', '绿色建筑碳中和'],
    painPoints: ['政策更新快，跟踪困难', '标准规范理解偏差', '补贴申请流程复杂'],
    solutions: ['AI政策跟踪分析', '智能合规检查', '自动化申请助手'],
    href: '#policy'
  },
  {
    id: 2,
    title: '行业发展前沿',
    subtitle: '趋势分析 · 市场动态 · 竞争情报',
    description: '分析建筑行业技术发展趋势、市场动态变化、竞争格局演变',
    icon: <TrendingUp className="h-6 w-6" />,
    color: 'green',
    stats: '1568+行业数据点',
    features: ['数字孪生应用', '装配式建筑技术', '新型建筑材料'],
    painPoints: ['技术趋势把握不准', '市场竞争压力大', '商业模式创新难'],
    solutions: ['市场趋势预测AI', '竞争情报分析系统', '商业模式优化算法'],
    href: '#industry'
  },
  {
    id: 3,
    title: 'AGENT前沿',
    subtitle: '工程Agent应用 · 落地案例 · 工具推荐',
    description: '探索AI Agent在结构工程领域的具体应用场景、实施案例',
    icon: <Cpu className="h-6 w-6" />,
    color: 'purple',
    stats: '89个工程Agent案例',
    features: ['设计优化Agent', '施工管理Agent', '运维监控Agent'],
    painPoints: ['设计效率低，重复计算多', '施工管理粗放', '运维数据缺失'],
    solutions: ['自动化方案生成Agent', '智能进度监控Agent', '预测性维护Agent'],
    href: '#agent'
  },
  {
    id: 4,
    title: 'AI前沿',
    subtitle: '结构工程AI技术 · 算法研究 · 实践指南',
    description: '深入研究AI技术在结构工程的具体应用、算法突破、实践方法',
    icon: <CpuIcon className="h-6 w-6" />,
    color: 'orange',
    stats: '42个AI工程应用',
    features: ['AI辅助结构分析', '机器学习荷载预测', '计算机视觉检测'],
    painPoints: ['结构计算工作繁琐', '荷载预测不准确', '质量检测效率低'],
    solutions: ['AI结构优化算法', '智能荷载预测模型', '自动化质量检测'],
    href: '#ai'
  },
  {
    id: 5,
    title: '智能设计前沿',
    subtitle: '设计工具 · 方法创新 · 流程优化',
    description: '关注设计工具智能化、设计方法创新、设计流程优化',
    icon: <DraftingCompass className="h-6 w-6" />,
    color: 'teal',
    stats: '35+智能设计工具',
    features: ['参数化设计', 'AI驱动优化', '自动化出图'],
    painPoints: ['设计工具学习成本高', '多专业协同困难', '出图工作繁琐'],
    solutions: ['智能设计助手', '协同设计平台', '自动化出图系统'],
    href: '#design'
  },
  {
    id: 6,
    title: '智能建造前沿',
    subtitle: '施工技术 · 智能设备 · 管理平台',
    description: '追踪施工技术创新、施工设备智能化、施工管理数字化',
    icon: <Construction className="h-6 w-6" />,
    color: 'red',
    stats: '28个智能建造案例',
    features: ['机器人施工', '物联网应用', '无人机监测'],
    painPoints: ['设计与施工偏差大', '现场质量控制困难', '进度管理不精准'],
    solutions: ['数字孪生偏差分析', '智能质量检测系统', '物联网进度监控'],
    href: '#construction'
  }
]

// 平台核心价值
const coreValues = [
  {
    icon: <Target className="h-5 w-5" />,
    title: '痛点导向',
    description: '深度分析结构工程师实际工作痛点'
  },
  {
    icon: <Zap className="h-5 w-5" />,
    title: '技术落地',
    description: '基于现有政策和技术支持的可实施方案'
  },
  {
    icon: <Users className="h-5 w-5" />,
    title: '个人发展',
    description: '规划结构工程师AI技能提升路径'
  },
  {
    icon: <Clock className="h-5 w-5" />,
    title: '持续更新',
    description: '每日自动抓取行业动态保持内容新鲜'
  }
]

export default function MobilePreviewPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeDimension, setActiveDimension] = useState(1)
  const [lastUpdate, setLastUpdate] = useState('刚刚')

  // 模拟更新时间
  useEffect(() => {
    const now = new Date()
    setLastUpdate(now.toLocaleTimeString('zh-CN', { 
      hour: '2-digit', 
      minute: '2-digit' 
    }))
  }, [])

  // 颜色映射
  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-50 border-blue-200 text-blue-700',
      green: 'bg-green-50 border-green-200 text-green-700',
      purple: 'bg-purple-50 border-purple-200 text-purple-700',
      orange: 'bg-orange-50 border-orange-200 text-orange-700',
      teal: 'bg-teal-50 border-teal-200 text-teal-700',
      red: 'bg-red-50 border-red-200 text-red-700'
    }
    return colors[color as keyof typeof colors] || colors.blue
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* 移动端顶部导航 */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg mr-3">
              <Smartphone className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h1 className="font-bold text-lg">结构工程师AI平台</h1>
              <p className="text-xs text-gray-500">手机端预览版</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <button 
              className="p-2 bg-gray-100 rounded-lg"
              onClick={() => window.location.reload()}
            >
              <RefreshCw className="h-4 w-4" />
            </button>
            <button 
              className="p-2 bg-gray-100 rounded-lg"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* 下拉菜单 */}
        {isMenuOpen && (
          <div className="absolute top-full left-0 right-0 bg-white border-b border-gray-200 shadow-lg">
            <div className="px-4 py-3">
              <div className="grid grid-cols-2 gap-2">
                {professionalDimensions.map((dim) => (
                  <a
                    key={dim.id}
                    href={dim.href}
                    className="flex items-center p-3 rounded-lg bg-gray-50 hover:bg-gray-100"
                    onClick={() => {
                      setActiveDimension(dim.id)
                      setIsMenuOpen(false)
                    }}
                  >
                    <div className="mr-3">{dim.icon}</div>
                    <span className="text-sm font-medium">{dim.title}</span>
                  </a>
                ))}
              </div>
            </div>
          </div>
        )}
      </header>

      {/* 状态栏 */}
      <div className="px-4 py-2 bg-blue-50 border-b border-blue-100">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center">
            <Globe className="h-3 w-3 mr-1 text-blue-600" />
            <span className="text-blue-700">在线预览</span>
          </div>
          <div className="flex items-center">
            <Clock className="h-3 w-3 mr-1 text-gray-500" />
            <span className="text-gray-600">更新: {lastUpdate}</span>
          </div>
        </div>
      </div>

      <main className="pb-20">
        {/* 英雄区域 */}
        <div className="px-4 pt-6 pb-4">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-3 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              结构工程师AI咨询平台
            </h2>
            <p className="text-gray-600 mb-4">
              6大维度深度分析行业痛点，提供可落地的AI/AGENT解决方案
            </p>
            
            <div className="flex flex-wrap justify-center gap-2 mb-6">
              <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
                政策前沿
              </span>
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                行业动态
              </span>
              <span className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-xs">
                Agent应用
              </span>
              <span className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-xs">
                AI技术
              </span>
            </div>
          </div>
        </div>

        {/* 数据统计 */}
        <div className="px-4 mb-6">
          <div className="grid grid-cols-4 gap-2">
            <div className="text-center p-3 bg-white rounded-xl border">
              <div className="text-lg font-bold text-blue-600">42+</div>
              <div className="text-xs text-gray-600">AI应用</div>
            </div>
            <div className="text-center p-3 bg-white rounded-xl border">
              <div className="text-lg font-bold text-green-600">89+</div>
              <div className="text-xs text-gray-600">Agent案例</div>
            </div>
            <div className="text-center p-3 bg-white rounded-xl border">
              <div className="text-lg font-bold text-purple-600">1568+</div>
              <div className="text-xs text-gray-600">数据点</div>
            </div>
            <div className="text-center p-3 bg-white rounded-xl border">
              <div className="text-lg font-bold text-orange-600">35+</div>
              <div className="text-xs text-gray-600">智能工具</div>
            </div>
          </div>
        </div>

        {/* 6大维度卡片 */}
        <div className="px-4 mb-6">
          <h3 className="text-lg font-bold mb-4 flex items-center">
            <Target className="h-5 w-5 mr-2 text-blue-600" />
            6大专业维度
          </h3>
          
          <div className="space-y-4">
            {professionalDimensions.map((dimension) => (
              <div
                key={dimension.id}
                className={`rounded-xl border-2 p-4 ${getColorClasses(dimension.color)} ${
                  activeDimension === dimension.id ? 'ring-2 ring-offset-2 ring-blue-500' : ''
                }`}
                onClick={() => setActiveDimension(dimension.id)}
              >
                <div className="flex items-start mb-3">
                  <div className="p-2 bg-white rounded-lg mr-3">
                    {dimension.icon}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold">{dimension.title}</h4>
                    <p className="text-sm text-gray-600">{dimension.subtitle}</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </div>
                
                <p className="text-sm text-gray-700 mb-3">{dimension.description}</p>
                
                <div className="flex items-center text-xs text-gray-500 mb-3">
                  <Zap className="h-3 w-3 mr-1" />
                  <span>{dimension.stats}</span>
                </div>
                
                {/* 核心特性标签 */}
                <div className="flex flex-wrap gap-1 mb-3">
                  {dimension.features.map((feature, idx) => (
                    <span key={idx} className="px-2 py-1 bg-white rounded-full text-xs border">
                      {feature}
                    </span>
                  ))}
                </div>
                
                {/* 痛点解决方案（展开时显示） */}
                {activeDimension === dimension.id && (
                  <div className="mt-3 pt-3 border-t border-gray-200">
                    <div className="mb-3">
                      <div className="flex items-center text-sm font-medium text-red-600 mb-2">
                        <AlertCircle className="h-4 w-4 mr-1" />
                        行业痛点
                      </div>
                      <ul className="space-y-1">
                        {dimension.painPoints.map((point, idx) => (
                          <li key={idx} className="flex items-start text-xs">
                            <span className="text-red-500 mr-1">•</span>
                            <span>{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <div className="flex items-center text-sm font-medium text-green-600 mb-2">
                        <CheckCircle className="h-4 w-4 mr-1" />
                        AI解决方案
                      </div>
                      <ul className="space-y-1">
                        {dimension.solutions.map((solution, idx) => (
                          <li key={idx} className="flex items-start text-xs">
                            <span className="text-green-500 mr-1">✓</span>
                            <span>{solution}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* 平台核心价值 */}
        <div className="px-4 mb-6">
          <h3 className="text-lg font-bold mb-4">✨ 平台核心价值</h3>
          <div className="grid grid-cols-2 gap-3">
            {coreValues.map((value, idx) => (
              <div key={idx} className="bg-white rounded-xl p-4 border">
                <div className="flex items-center mb-2">
                  <div className="p-2 bg-gray-100 rounded-lg mr-3">
                    {value.icon}
                  </div>
                  <h4 className="font-medium">{value.title}</h4>
                </div>
                <p className="text-sm text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* 自动更新系统 */}
        <div className="px-4 mb-6">
          <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl p-5 text-white">
            <h3 className="text-lg font-bold mb-3 flex items-center">
              <RefreshCw className="h-5 w-5 mr-2" />
              每日自动更新系统
            </h3>
            <p className="text-blue-100 mb-4 text-sm">
              本平台每日自动抓取政策动态、行业资讯、技术突破，保持内容最新鲜、最相关
            </p>
            <div className="flex space-x-3">
              <button className="flex-1 px-4 py-2 bg-white text-blue-600 font-medium rounded-lg text-sm">
                查看今日更新
              </button>
              <button className="flex-1 px-4 py-2 bg-transparent border-2 border-white text-white font-medium rounded-lg text-sm">
                订阅通知
              </button>
            </div>
          </div>
        </div>

        {/* 快速导航 */}
        <div className="px-4 mb-6">
          <h3 className="text-lg font-bold mb-4">🚀 快速导航</h3>
          <div className="grid grid-cols-3 gap-3">
            <a href="#policy" className="text-center p-3 bg-blue-50 rounded-xl border border-blue-200">
              <Building2 className="h-5 w-5 mx-auto mb-2 text-blue-600" />
              <span className="text-sm font-medium">政策</span>
            </a>
            <a href="#ai" className="text-center p-3 bg-orange-50 rounded-xl border border-orange-200">
              <CpuIcon className="h-5 w-5 mx-auto mb-2 text-orange-600" />
              <span className="text-sm font-medium">AI技术</span>
            </a>
            <a href="#design" className="text-center p-3 bg-teal-50 rounded-xl border border-teal-200">
              <DraftingCompass className="h-5 w-5 mx-auto mb-2 text-teal-600" />
              <span className="text-sm font-medium">设计</span>
            </a>
            <a href="#agent" className="text-center p-3 bg-purple-50 rounded-xl border border-purple-200">
              <Cpu className="h-5 w-5 mx-auto mb-2 text-purple-600" />
              <span className="text-sm font-medium">Agent</span>
            </a>
            <a href="#construction" className="text-center p-3 bg-red-50 rounded-xl border border-red-200">
              <Construction className="h-5 w-5 mx-auto mb-2 text-red-600" />
              <span className="text-sm font-medium">建造</span>
            </a>
            <a href="#industry" className="text-center p-3 bg-green-50 rounded-xl border border-green-200">
              <TrendingUp className="h-5 w-5 mx-auto mb-2 text-green-600" />
              <span className="text-sm font-medium">行业</span>
            </a>
          </div>
        </div>
      </main>

      {/* 移动端底部导航 */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-3 px-4">
        <div className="flex justify-between items-center">
          <button className="flex flex-col items-center">
            <div className="p-2 bg-blue-50 rounded-lg mb-1">
              <Globe className="h-5 w-5 text-blue-600" />
            </div>
            <span className="text-xs text-blue-600">首页</span>
          </button>
          
          <button className="flex flex-col items-center">
            <div className="p-2 bg-gray-100 rounded-lg mb-1">
              <Target className="h-5 w-5 text-gray-600" />
            </div>
            <span className="text-xs text-gray-600">维度</span>
          </button>
          
          <button className="flex flex-col items-center">
            <div className="p-2 bg-gray-100 rounded-lg mb-1">
              <Download className="h-5 w-5 text-gray-600" />
            </div>
            <span className="text-xs text-gray-600">下载</span>
          </button>
          
          <button className="flex flex-col items-center">
            <div className="p-2 bg-gray-100 rounded-lg mb-1">
              <ExternalLink className="h-5 w-5 text-gray-600" />
            </div>
            <span className="text-xs text-gray-600">更多</span>
          </button>
        </div>
        
        <div className="mt-3 text-center">
          <p className="text-xs text-gray-500">
            结构工程师AI咨询平台 · 手机端预览版
          </p>
          <p className="text-xs text-gray-400 mt-1">
            最后更新: 2026-04-10 22:37 · 优化适配所有手机屏幕
          </p>
        </div>
      </footer>
    </div>
  )
}