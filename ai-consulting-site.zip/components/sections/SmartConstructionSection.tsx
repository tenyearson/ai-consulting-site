'use client'

import { useState } from 'react'
import { Building, Cpu, TrendingUp, MapPin, Calendar, FileText, Users, Award } from 'lucide-react'

// 模拟智能建造数据
const mockConstructionProjects = [
  {
    id: 1,
    title: '基于数字孪生的智能桥梁监测系统',
    description: '利用AI和物联网技术实现桥梁结构健康实时监测',
    category: '数字孪生',
    location: '上海',
    stage: '已落地',
    impact: '降低维护成本40%，延长使用寿命15年',
    technology: ['BIM建模', '传感器网络', 'AI预测分析', '云计算'],
    researchInstitution: '清华大学土木工程系',
    industryPartner: '中国交建',
    caseStudy: 'https://example.com/case1',
    year: 2025,
  },
  {
    id: 2,
    title: 'AI驱动的智能施工安全管理平台',
    description: '计算机视觉识别施工现场安全隐患',
    category: '施工安全',
    location: '深圳',
    stage: '试点推广',
    impact: '事故率下降60%，响应时间缩短80%',
    technology: ['计算机视觉', '边缘计算', '实时预警', '移动端应用'],
    researchInstitution: '华南理工大学',
    industryPartner: '万科集团',
    caseStudy: 'https://example.com/case2',
    year: 2024,
  },
  {
    id: 3,
    title: '3D打印混凝土智能建造技术',
    description: '自动化3D打印建筑结构，减少人工依赖',
    category: '智能建造',
    location: '北京',
    stage: '研发阶段',
    impact: '施工效率提升300%，材料浪费减少70%',
    technology: ['机器人控制', '材料科学', '路径规划', '质量检测'],
    researchInstitution: '同济大学',
    industryPartner: '中建集团',
    caseStudy: 'https://example.com/case3',
    year: 2026,
  },
  {
    id: 4,
    title: '基于BIM的智能运维管理系统',
    description: '建筑全生命周期数字化管理平台',
    category: '智能运维',
    location: '杭州',
    stage: '规模化应用',
    impact: '能耗降低35%，运维效率提升50%',
    technology: ['BIM集成', '大数据分析', '预测性维护', '移动巡检'],
    researchInstitution: '浙江大学',
    industryPartner: '阿里巴巴',
    caseStudy: 'https://example.com/case4',
    year: 2023,
  },
]

const categories = ['全部', '数字孪生', '施工安全', '智能建造', '智能运维', '绿色建筑', '装配式建筑']
const stages = ['全部', '研发阶段', '试点推广', '已落地', '规模化应用']

export default function SmartConstructionSection() {
  const [selectedCategory, setSelectedCategory] = useState('全部')
  const [selectedStage, setSelectedStage] = useState('全部')
  const [expandedId, setExpandedId] = useState<number | null>(null)

  const filteredProjects = mockConstructionProjects.filter(project => {
    const categoryMatch = selectedCategory === '全部' || project.category === selectedCategory
    const stageMatch = selectedStage === '全部' || project.stage === selectedStage
    return categoryMatch && stageMatch
  })

  const handleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id)
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      {/* 标题 */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold flex items-center">
            <Building className="mr-3 h-6 w-6 text-green-500" />
            智能建造创新
            <span className="ml-3 text-sm font-normal text-gray-500 dark:text-gray-400">
              研究成果 • 落地应用
            </span>
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            材料-结构-智能化建造领域的最新研究成果和产业应用
          </p>
        </div>
        <TrendingUp className="h-8 w-8 text-green-500" />
      </div>

      {/* 双重筛选 */}
      <div className="mb-6 space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            技术分类
          </label>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                  selectedCategory === category
                    ? 'bg-green-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            应用阶段
          </label>
          <div className="flex flex-wrap gap-2">
            {stages.map((stage) => (
              <button
                key={stage}
                onClick={() => setSelectedStage(stage)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                  selectedStage === stage
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {stage}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 项目列表 */}
      <div className="space-y-4">
        {filteredProjects.map((project) => (
          <div
            key={project.id}
            className={`border rounded-lg overflow-hidden transition-all duration-300 ${
              expandedId === project.id
                ? 'border-green-300 dark:border-green-700 bg-green-50 dark:bg-green-900/20'
                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
            }`}
          >
            {/* 项目头部 */}
            <div 
              className="p-4 cursor-pointer"
              onClick={() => handleExpand(project.id)}
            >
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      project.stage === '已落地' ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300' :
                      project.stage === '规模化应用' ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300' :
                      'bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300'
                    }`}>
                      {project.stage}
                    </span>
                    <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-xs font-medium">
                      {project.category}
                    </span>
                    <span className="flex items-center text-xs text-gray-500">
                      <MapPin className="h-3 w-3 mr-1" />
                      {project.location}
                    </span>
                    <span className="flex items-center text-xs text-gray-500">
                      <Calendar className="h-3 w-3 mr-1" />
                      {project.year}年
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-semibold mb-2">
                    {project.title}
                  </h3>
                  
                  <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">
                    {project.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-500">
                      <span className="flex items-center">
                        <Award className="h-4 w-4 mr-1" />
                        成效: {project.impact}
                      </span>
                    </div>
                    <button className="text-green-500 hover:text-green-600 text-sm font-medium">
                      {expandedId === project.id ? '收起详情' : '查看详情'}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* 展开的详情 */}
            {expandedId === project.id && (
              <div className="px-4 pb-4 pt-2 border-t border-gray-200 dark:border-gray-700 animate-slide-up">
                {/* 技术栈 */}
                <div className="mb-4">
                  <h4 className="font-medium mb-2 text-gray-700 dark:text-gray-300 flex items-center">
                    <Cpu className="h-4 w-4 mr-2" />
                    核心技术
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {project.technology.map((tech, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full text-xs"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* 合作机构 */}
                <div className="mb-4">
                  <h4 className="font-medium mb-2 text-gray-700 dark:text-gray-300 flex items-center">
                    <Users className="h-4 w-4 mr-2" />
                    合作机构
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-3">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        科研机构
                      </div>
                      <div className="text-gray-600 dark:text-gray-400">
                        {project.researchInstitution}
                      </div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-3">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        产业伙伴
                      </div>
                      <div className="text-gray-600 dark:text-gray-400">
                        {project.industryPartner}
                      </div>
                    </div>
                  </div>
                </div>

                {/* 详细影响 */}
                <div className="mb-4">
                  <h4 className="font-medium mb-2 text-gray-700 dark:text-gray-300">
                    📈 详细影响分析
                  </h4>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    {project.impact}。该项目通过{project.technology.join('、')}等技术的综合应用，
                    在{project.category}领域实现了突破性进展，为行业提供了可复制的解决方案。
                  </p>
                </div>

                {/* 操作按钮 */}
                <div className="flex flex-wrap gap-3">
                  <a
                    href={project.caseStudy}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm font-medium transition-colors"
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    查看案例研究
                  </a>
                  <button className="inline-flex items-center px-4 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-sm font-medium transition-colors">
                    技术白皮书
                  </button>
                  <button className="inline-flex items-center px-4 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg text-sm font-medium transition-colors">
                    联系合作
                  </button>
                </div>

                <div className="mt-4 text-xs text-gray-500">
                  <p>🏗️ 项目规模: 大型示范项目 • 📊 数据来源: 实地调研+行业报告</p>
                  <p className="mt-1">🔍 相关领域: #智能建造 #{project.category} #{project.location}建筑</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* 底部统计 */}
      <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-green-600">42</div>
            <div className="text-sm text-gray-500">落地案例</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-blue-600">28</div>
            <div className="text-sm text-gray-500">科研机构</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-purple-600">15</div>
            <div className="text-sm text-gray-500">技术专利</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-orange-600">¥3.2亿</div>
            <div className="text-sm text-gray-500">经济效益</div>
          </div>
        </div>
        
        <div className="mt-4 text-center">
          <button className="px-4 py-2 bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white rounded-lg font-medium transition-all">
            提交创新项目
          </button>
        </div>
      </div>
    </div>
  )
}