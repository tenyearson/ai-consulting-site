'use client'

import { useState } from 'react'
import { Target, BookOpen, TrendingUp, Users, Clock, Award, CheckCircle, Calendar, Zap, Brain } from 'lucide-react'

// 学习路径数据
const learningPaths = [
  {
    id: 1,
    level: '入门阶段',
    duration: '1-2个月',
    target: 'AI基础认知和工具使用',
    description: '建立AI基础认知，掌握核心工具使用',
    milestones: [
      { name: 'AI基础概念学习', completed: true, resources: ['吴恩达AI课程', '李宏毅机器学习'] },
      { name: 'ChatGPT等工具熟练使用', completed: true, resources: ['官方文档', '实用技巧教程'] },
      { name: 'AI应用场景了解', completed: false, resources: ['行业案例研究', '应用场景分析'] },
      { name: '基础Prompt工程', completed: false, resources: ['Prompt工程指南', '最佳实践'] }
    ],
    tools: ['ChatGPT', 'Midjourney', 'Notion AI', 'Grammarly'],
    timeCommitment: '每周5-8小时'
  },
  {
    id: 2,
    level: '进阶阶段',
    duration: '3-6个月',
    target: 'AI增强工作流建立',
    description: '将AI工具整合到工作流中，提升工作效率',
    milestones: [
      { name: '工作流AI化改造', completed: false, resources: ['工作流分析', '工具集成指南'] },
      { name: '专业领域AI应用', completed: false, resources: ['行业AI解决方案', '专业工具学习'] },
      { name: '数据分析和决策支持', completed: false, resources: ['数据分析工具', '决策模型'] },
      { name: '团队协作AI工具', completed: false, resources: ['协作平台', '项目管理工具'] }
    ],
    tools: ['GitHub Copilot', 'Tableau', 'Power BI', 'Miro AI'],
    timeCommitment: '每周8-12小时'
  },
  {
    id: 3,
    level: '专业阶段',
    duration: '6-12个月',
    target: 'AI驱动创新和业务',
    description: '利用AI创造新价值，驱动业务创新',
    milestones: [
      { name: 'AI产品开发能力', completed: false, resources: ['产品设计', '技术架构'] },
      { name: '商业模式AI创新', completed: false, resources: ['商业模式画布', '创新方法论'] },
      { name: '技术趋势把握', completed: false, resources: ['技术雷达', '趋势分析'] },
      { name: '领导AI转型', completed: false, resources: ['变革管理', '团队赋能'] }
    ],
    tools: ['Custom GPTs', 'AI APIs', 'AutoML', 'LangChain'],
    timeCommitment: '每周10-15小时'
  }
]

// 技能转型策略
const skillTransition = [
  {
    from: '传统文案',
    to: 'AI增强内容创作',
    strategy: '学习Prompt工程 + AI写作工具 + 内容策略',
    timeline: '2-3个月',
    successRate: '85%',
    resources: ['AI写作课程', '内容策略指南', '案例研究']
  },
  {
    from: '基础数据分析',
    to: 'AI驱动数据分析',
    strategy: '学习Python + 数据分析库 + AI分析工具',
    timeline: '3-4个月',
    successRate: '80%',
    resources: ['Python数据分析', '机器学习基础', '工具实战']
  },
  {
    from: '传统营销',
    to: 'AI智能营销',
    strategy: '学习营销自动化 + 用户分析 + 个性化推荐',
    timeline: '2-3个月',
    successRate: '90%',
    resources: ['营销自动化工具', '用户行为分析', 'AI推荐系统']
  },
  {
    from: '项目管理',
    to: 'AI智能项目管理',
    strategy: '学习AI项目管理工具 + 预测分析 + 资源优化',
    timeline: '1-2个月',
    successRate: '95%',
    resources: ['项目管理AI工具', '预测模型', '优化算法']
  }
]

// 学习资源推荐
const learningResources = [
  {
    category: '在线课程',
    items: [
      { name: '吴恩达AI For Everyone', platform: 'Coursera', free: true, hours: 10 },
      { name: '李宏毅机器学习', platform: 'YouTube', free: true, hours: 60 },
      { name: 'Fast.ai深度学习', platform: 'fast.ai', free: true, hours: 40 },
      { name: 'Google AI课程', platform: 'Google', free: true, hours: 20 }
    ]
  },
  {
    category: '书籍推荐',
    items: [
      { name: '人工智能：现代方法', author: 'Stuart Russell', level: '进阶', pages: 1152 },
      { name: '机器学习', author: '周志华', level: '专业', pages: 425 },
      { name: '深度学习', author: 'Ian Goodfellow', level: '专业', pages: 800 },
      { name: 'AI极简经济学', author: 'Ajay Agrawal', level: '入门', pages: 256 }
    ]
  },
  {
    category: '实践社区',
    items: [
      { name: 'Kaggle', type: '数据科学竞赛', active: '200万+用户' },
      { name: 'GitHub AI项目', type: '开源项目', active: '50万+项目' },
      { name: 'Hugging Face', type: '模型社区', active: '10万+模型' },
      { name: 'AI技术论坛', type: '技术讨论', active: '活跃社区' }
    ]
  }
]

export default function PersonalDevelopmentSection() {
  const [activePath, setActivePath] = useState<number>(1)
  const [progress, setProgress] = useState({
    stage1: 50,
    stage2: 20,
    stage3: 5
  })

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      {/* 标题和价值主张 */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold flex items-center text-yellow-700 dark:text-yellow-400">
          <Brain className="mr-3 h-7 w-7" />
          个人发展指南 · 实用学习
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mt-3 text-lg">
          学习AI不必焦虑，关键在于明确目标、务实行动、善用工具而非被工具所困
        </p>
        <div className="mt-4">
          <div className="inline-flex items-center px-4 py-2 bg-yellow-100 dark:bg-yellow-900 rounded-lg">
            <span className="font-medium text-yellow-800 dark:text-yellow-300 mr-2">核心理念：</span>
            <span className="text-sm">AI技术发展是马拉松而非百米冲刺，关键不在于你跑得多快，而在于你是否找到了自己的节奏</span>
          </div>
        </div>
      </div>

      {/* 学习进度概览 */}
      <div className="mb-8">
        <h3 className="text-lg font-bold mb-4 flex items-center">
          <TrendingUp className="h-5 w-5 mr-2 text-yellow-500" />
          个人AI学习进度概览
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {learningPaths.map((path, index) => (
            <div key={path.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
              <div className="flex items-center mb-3">
                <div className={`w-10 h-10 flex items-center justify-center rounded-full mr-3 ${
                  index === 0 ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300' :
                  index === 1 ? 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300' :
                  'bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300'
                }`}>
                  {index + 1}
                </div>
                <div>
                  <div className="font-medium">{path.level}</div>
                  <div className="text-sm text-gray-500">{path.duration}</div>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                  {path.description}
                </div>
                <div className="text-sm font-medium">目标：{path.target}</div>
              </div>
              
              <div className="mb-4">
                <div className="text-sm text-gray-500 mb-2">时间投入：{path.timeCommitment}</div>
                <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${
                      index === 0 ? 'bg-green-500' :
                      index === 1 ? 'bg-blue-500' :
                      'bg-purple-500'
                    }`}
                    style={{ width: `${index === 0 ? progress.stage1 : index === 1 ? progress.stage2 : progress.stage3}%` }}
                  ></div>
                </div>
              </div>
              
              <button
                onClick={() => setActivePath(path.id)}
                className={`w-full py-2 rounded-lg text-sm font-medium transition-colors ${
                  activePath === path.id
                    ? 'bg-yellow-500 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {activePath === path.id ? '正在学习' : '查看详情'}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* 当前阶段详情 */}
      <div className="mb-8">
        <h3 className="text-lg font-bold mb-4 flex items-center">
          <Target className="h-5 w-5 mr-2 text-yellow-500" />
          {learningPaths.find(p => p.id === activePath)?.level} - 详细学习计划
        </h3>
        
        {learningPaths.find(p => p.id === activePath) && (
          <div className="border border-yellow-200 dark:border-yellow-800 rounded-lg p-5 bg-yellow-50 dark:bg-yellow-900/20">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="font-medium text-lg">{learningPaths.find(p => p.id === activePath)?.target}</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    预计完成时间：{learningPaths.find(p => p.id === activePath)?.duration}
                  </div>
                </div>
                <div className="text-sm text-gray-500">
                  每周投入：{learningPaths.find(p => p.id === activePath)?.timeCommitment}
                </div>
              </div>
              
              <div className="mb-6">
                <h4 className="font-medium mb-3">关键里程碑</h4>
                <div className="space-y-4">
                  {learningPaths.find(p => p.id === activePath)?.milestones.map((milestone, index) => (
                    <div key={index} className="flex items-start">
                      <div className={`w-8 h-8 flex items-center justify-center rounded-full mr-4 ${
                        milestone.completed
                          ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                      }`}>
                        {milestone.completed ? <CheckCircle className="h-5 w-5" /> : index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="font-medium mb-2">{milestone.name}</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                          学习资源：{milestone.resources.join('、')}
                        </div>
                        {!milestone.completed && (
                          <button className="text-sm text-yellow-600 dark:text-yellow-400 hover:underline">
                            开始学习 →
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <h4 className="font-medium mb-3">推荐工具</h4>
                <div className="flex flex-wrap gap-3">
                  {learningPaths.find(p => p.id === activePath)?.tools.map((tool, index) => (
                    <div key={index} className="px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg">
                      <div className="font-medium">{tool}</div>
                      <div className="text-xs text-gray-500">必备工具</div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4">
                <h4 className="font-medium mb-3">学习建议</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                  <li className="flex items-start">
                    <span className="text-yellow-500 mr-2">•</span>
                    <span>制定每周学习计划，保持连续性</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-yellow-500 mr-2">•</span>
                    <span>理论与实践结合，每个概念都要动手实践</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-yellow-500 mr-2">•</span>
                    <span>加入学习社区，与他人交流讨论</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-yellow-500 mr-2">•</span>
                    <span>定期回顾和调整学习计划</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 技能转型策略 */}
      <div className="mb-8">
        <h3 className="text-lg font-bold mb-4 flex items-center">
          <Zap className="h-5 w-5 mr-2 text-yellow-500" />
          技能转型策略指南
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {skillTransition.map((transition, index) => (
            <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="font-medium text-gray-500">从</div>
                  <div className="text-lg font-medium">{transition.from}</div>
                </div>
                <div className="text-2xl text-gray-300 dark:text-gray-600">→</div>
                <div>
                  <div className="font-medium text-gray-500">到</div>
                  <div className="text-lg font-medium text-yellow-600 dark:text-yellow-400">{transition.to}</div>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="text-sm font-medium mb-2">转型策略</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  {transition.strategy}
                </div>
              </div>
              
              <div className="flex justify-between items-center mb-4">
                <div>
                  <div className="text-sm text-gray-500">预计时间</div>
                  <div className="font-medium">{transition.timeline}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">成功率</div>
                  <div className="font-medium text-green-600 dark:text-green-400">{transition.successRate}</div>
                </div>
              </div>
              
              <div>
                <div className="text-sm font-medium mb-2">学习资源</div>
                <div className="flex flex-wrap gap-2">
                  {transition.resources.map((resource, idx) => (
                    <span key={idx} className="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-xs">
                      {resource}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 学习资源推荐 */}
      <div className="mb-8">
        <h3 className="text-lg font-bold mb-4 flex items-center">
          <BookOpen className="h-5 w-5 mr-2 text-yellow-500" />
          优质学习资源推荐
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {learningResources.map((resource, index) => (
            <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg p-5">
              <h4 className="font-medium mb-4">{resource.category}</h4>
              <div className="space-y-4">
                {resource.items.map((item, idx) => (
                  <div key={idx} className="pb-4 border-b border-gray-100 dark:border-gray-800 last:border-0 last:pb-0">
                    <div className="font-medium mb-1">{item.name}</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      {'platform' in item ? `${item.platform} · ${item.free ? '免费' : '付费'}` : 
                       'author' in item ? `${item.author} · ${item.level}` :
                       `${item.type} · ${item.active}`}
                    </div>
                    <div className="text-xs text-gray-500">
                      {'hours' in item ? `约${item.hours}小时` :
                       'pages' in item ? `${item.pages}页` :
                       '活跃社区'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 学习系统构建 */}
      <div className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-xl p-6">
        <h3 className="text-xl font-bold mb-4 flex items-center">
          <Calendar className="h-6 w-6 mr-3 text-yellow-500" />
          构建个人终身学习系统
        </h3>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          与其焦虑被技术淘汰，不如主动拥抱变化、提升自我——技术浪潮奔涌向前，唯有以终身学习应对技术迭代，以核心能力对抗时代焦虑，才能真正做技术的主人。
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400 mb-2">1</div>
            <div className="font-medium mb-2">明确目标</div>
            <div className="text-sm text-gray-600 dark:text-gray-400">根据职业规划设定学习方向</div>
          </div>
          <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400 mb-2">2</div>
            <div className="font-medium mb-2">务实行动</div>
            <div className="text-sm text-gray-600 dark:text-gray-400">制定可执行的学习计划</div>
          </div>
          <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400 mb-2">3</div>
            <div className="font-medium mb-2">善用工具</div>
            <div className="text-sm text-gray-600 dark:text-gray-400">利用AI工具提升学习效率</div>
          </div>
          <div className="text-center p-4 bg-white dark:bg-gray-800 rounded-lg">
            <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400 mb-2">4</div>
            <div className="font-medium mb-2">持续迭代</div>
            <div className="text-sm text-gray-600 dark:text-gray-400">定期评估和调整学习策略</div>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-600 dark:text-gray-400">
            记住：技术马拉松中，找到自己的节奏比盲目追赶更重要
          </div>
          <button className="px-5 py-2.5 bg-yellow-500 hover:bg-yellow-600 text-white rounded-lg font-medium flex items-center transition-colors">
            <Award className="h-4 w-4 mr-2" />
            制定我的学习计划
          </button>
        </div>
      </div>

      {/* 成功案例 */}
      <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-bold mb-4">成功转型案例</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 border border-gray-200 dark:border-gray-700 rounded-lg">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold text-xl mr-4">
                张
              </div>
              <div>
                <div className="font-medium">传统文案 → AI内容策略师</div>
                <div className="text-sm text-gray-500">转型时间：3个月</div>
              </div>
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              "通过学习Prompt工程和AI写作工具，现在一个人可以完成原来一个团队的工作量，收入提升了3倍。"
            </div>
          </div>
          <div className="p-5 border border-gray-200 dark:border-gray-700 rounded-lg">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center text-green-600 dark:text-green-400 font-bold text-xl mr-4">
                李
              </div>
              <div>
                <div className="font-medium">数据分析师 → AI产品经理</div>
                <div className="text-sm text-gray-500">转型时间：6个月</div>
              </div>
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              "结合数据分析能力和AI产品知识，现在负责公司核心AI产品线，职业发展空间大幅扩展。"
            </div>
          </div>
          <div className="p-5 border border-gray-200 dark:border-gray-700 rounded-lg">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center text-purple-600 dark:text-purple-400 font-bold text-xl mr-4">
                王
              </div>
              <div>
                <div className="font-medium">市场营销 → AI营销顾问</div>
                <div className="text-sm text-gray-500">转型时间：4个月</div>
              </div>
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              "将AI工具应用到营销全流程，现在为多家企业提供AI营销咨询服务，实现了职业自由。"
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}