import { NextResponse } from 'next/server'

// 模拟新闻数据 - 实际应替换为真实API
const mockNews = [
  {
    id: 1,
    title: 'AI大模型在智能建造领域取得突破',
    summary: '最新研究显示，AI大模型在建筑设计和施工优化方面表现优异',
    category: '智能建造',
    date: '2026-04-19',
    source: 'AI前沿研究'
  },
  {
    id: 2,
    title: '政策支持建筑行业数字化转型',
    summary: '国家发布新政策，鼓励建筑企业采用数字化技术提升效率',
    category: '政策前沿',
    date: '2026-04-18',
    source: '政策动态'
  },
  {
    id: 3,
    title: '新型建筑材料研发进展',
    summary: '科研团队开发出更环保、更耐用的新型建筑材料',
    category: '技术前沿',
    date: '2026-04-17',
    source: '技术周刊'
  }
]

export async function GET() {
  try {
    // 这里可以添加真实API调用
    // const response = await fetch('https://真实新闻API地址')
    // const data = await response.json()
    
    return NextResponse.json({
      success: true,
      data: mockNews,
      timestamp: new Date().toISOString(),
      count: mockNews.length
    })
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: '数据获取失败',
      timestamp: new Date().toISOString()
    }, { status: 500 })
  }
}

export const revalidate = 3600 // 每小时重新验证
