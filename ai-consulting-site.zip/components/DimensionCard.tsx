'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ChevronRight, AlertCircle, CheckCircle, Zap, Target } from 'lucide-react'

interface DimensionCardProps {
  dimension: {
    id: number
    title: string
    subtitle: string
    description: string
    icon: React.ReactNode
    color: string
    stats: string
    features: string[]
    painPoints: string[]
    solutions: string[]
    href: string
    cta: string
  }
}

export default function DimensionCard({ dimension }: DimensionCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [showDetails, setShowDetails] = useState(false)

  // 颜色映射
  const colorClasses = {
    blue: {
      bg: 'bg-blue-50 dark:bg-blue-900/20',
      border: 'border-blue-200 dark:border-blue-800',
      text: 'text-blue-700 dark:text-blue-400',
      hover: 'hover:border-blue-300 dark:hover:border-blue-700',
      iconBg: 'bg-blue-100 dark:bg-blue-800',
      iconText: 'text-blue-600 dark:text-blue-300',
      badge: 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-300'
    },
    green: {
      bg: 'bg-green-50 dark:bg-green-900/20',
      border: 'border-green-200 dark:border-green-800',
      text: 'text-green-700 dark:text-green-400',
      hover: 'hover:border-green-300 dark:hover:border-green-700',
      iconBg: 'bg-green-100 dark:bg-green-800',
      iconText: 'text-green-600 dark:text-green-300',
      badge: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300'
    },
    purple: {
      bg: 'bg-purple-50 dark:bg-purple-900/20',
      border: 'border-purple-200 dark:border-purple-800',
      text: 'text-purple-700 dark:text-purple-400',
      hover: 'hover:border-purple-300 dark:hover:border-purple-700',
      iconBg: 'bg-purple-100 dark:bg-purple-800',
      iconText: 'text-purple-600 dark:text-purple-300',
      badge: 'bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-300'
    },
    orange: {
      bg: 'bg-orange-50 dark:bg-orange-900/20',
      border: 'border-orange-200 dark:border-orange-800',
      text: 'text-orange-700 dark:text-orange-400',
      hover: 'hover:border-orange-300 dark:hover:border-orange-700',
      iconBg: 'bg-orange-100 dark:bg-orange-800',
      iconText: 'text-orange-600 dark:text-orange-300',
      badge: 'bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-300'
    },
    teal: {
      bg: 'bg-teal-50 dark:bg-teal-900/20',
      border: 'border-teal-200 dark:border-teal-800',
      text: 'text-teal-700 dark:text-teal-400',
      hover: 'hover:border-teal-300 dark:hover:border-teal-700',
      iconBg: 'bg-teal-100 dark:bg-teal-800',
      iconText: 'text-teal-600 dark:text-teal-300',
      badge: 'bg-teal-100 dark:bg-teal-900 text-teal-800 dark:text-teal-300'
    },
    red: {
      bg: 'bg-red-50 dark:bg-red-900/20',
      border: 'border-red-200 dark:border-red-800',
      text: 'text-red-700 dark:text-red-400',
      hover: 'hover:border-red-300 dark:hover:border-red-700',
      iconBg: 'bg-red-100 dark:bg-red-800',
      iconText: 'text-red-600 dark:text-red-300',
      badge: 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-300'
    }
  }

  const colors = colorClasses[dimension.color as keyof typeof colorClasses] || colorClasses.blue

  return (
    <div
      className={`
        relative h-full rounded-xl border-2 p-6 transition-all duration-300
        ${colors.bg} ${colors.border} ${colors.hover}
        ${isHovered ? 'shadow-lg' : 'shadow-sm'}
        cursor-pointer overflow-hidden
      `}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => setShowDetails(!showDetails)}
    >
      {/* 维度头部 */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center mb-3">
            <div className={`p-3 rounded-lg ${colors.iconBg} mr-4`}>
              <div className={colors.iconText}>
                {dimension.icon}
              </div>
            </div>
            <div>
              <h3 className={`text-xl font-bold ${colors.text}`}>
                {dimension.title}
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {dimension.subtitle}
              </p>
            </div>
          </div>
          
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            {dimension.description}
          </p>
          
          <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-4">
            <Zap className="h-4 w-4 mr-1" />
            <span>{dimension.stats}</span>
          </div>
        </div>
      </div>

      {/* 核心特性 */}
      <div className="mb-4">
        <h4 className="font-medium mb-2 flex items-center">
          <Target className="h-4 w-4 mr-2" />
          核心关注
        </h4>
        <div className="flex flex-wrap gap-2">
          {dimension.features.slice(0, 3).map((feature, index) => (
            <span key={index} className="px-3 py-1 bg-white dark:bg-gray-800 rounded-full text-xs border">
              {feature}
            </span>
          ))}
          {dimension.features.length > 3 && (
            <span className="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-xs">
              +{dimension.features.length - 3}项
            </span>
          )}
        </div>
      </div>

      {/* 展开的详细信息 */}
      {showDetails && (
        <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
          {/* 行业痛点 */}
          <div className="mb-4">
            <h4 className="font-medium mb-2 flex items-center text-red-600 dark:text-red-400">
              <AlertCircle className="h-4 w-4 mr-2" />
              行业痛点
            </h4>
            <ul className="space-y-2">
              {dimension.painPoints.map((point, index) => (
                <li key={index} className="flex items-start text-sm">
                  <span className="text-red-500 mr-2">•</span>
                  <span className="text-gray-700 dark:text-gray-300">{point}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* AI解决方案 */}
          <div className="mb-4">
            <h4 className="font-medium mb-2 flex items-center text-green-600 dark:text-green-400">
              <CheckCircle className="h-4 w-4 mr-2" />
              AI解决方案
            </h4>
            <ul className="space-y-2">
              {dimension.solutions.map((solution, index) => (
                <li key={index} className="flex items-start text-sm">
                  <span className="text-green-500 mr-2">✓</span>
                  <span className="text-gray-700 dark:text-gray-300">{solution}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* 底部操作区域 */}
      <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-between items-center">
        <button
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${colors.badge}`}
          onClick={(e) => {
            e.stopPropagation()
            setShowDetails(!showDetails)
          }}
        >
          {showDetails ? '收起详情' : '查看详情'}
        </button>
        
        <Link
          href={dimension.href}
          className="flex items-center px-4 py-2 bg-gray-900 dark:bg-gray-700 text-white rounded-lg hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors"
          onClick={(e) => e.stopPropagation()}
        >
          {dimension.cta}
          <ChevronRight className="h-4 w-4 ml-1" />
        </Link>
      </div>

      {/* 悬停效果装饰 */}
      {isHovered && (
        <div className="absolute top-0 right-0 w-16 h-16 opacity-10">
          <div className={`w-full h-full ${colors.iconBg} rounded-full`} />
        </div>
      )}
    </div>
  )
}