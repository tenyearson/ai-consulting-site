'use client'

import { useState } from 'react'
import { Factory, Zap, Cpu, TrendingUp, Download, Wrench, BarChart, Users } from 'lucide-react'

// 工业制造场景数据
const industrialScenarios = [
  {
    id: 1,
    title: '智能工厂全流程生产应用',
    description: '从原材料到成品的无人化智能生产全流程',
    category: '工业制造',
    stages: [
      '智能采购与供应链',
      '自动化生产线',
      '质量智能检测',
      '智能仓储物流',
      '预测性维护',
      '能源智能管理'
    ],
    benefits: [
      '生产效率提升40-60%',
      '人工成本降低50-70%',
      '质量缺陷率降低80%',
      '能源消耗降低30%'
    ],
    tools: [
      { name: '西门子MindSphere', type: '工业物联网平台', link: 'https://siemens.com/mindsphere' },
      { name: 'PTC ThingWorx', type: '数字孪生平台', link: 'https://ptc.com/thingworx' },
      { name: '达索3DEXPERIENCE', type: '智能制造平台', link: 'https://3ds.com' },
      { name: '华为云工业智能体', type: 'AI工业平台', link: 'https://huaweicloud.com' }
    ],
    flowchartSteps: [
      '需求预测 → 智能排产',
      '原材料智能采购',
      '自动化生产线执行',
      '实时质量监控',
      '智能仓储与配送',
      '设备预测性维护',
      '能源消耗优化',
      '数据分析与优化'
    ]
  },
  {
    id: 2,
    title: '能源智能化管理应用',
    description: '从能源生产到消费的全链条智能优化管理',
    category: '能源利用',
    stages: [
      '智能发电预测',
      '电网智能调度',
      '用能实时监测',
      '能效智能优化',
      '储能智能管理',
      '碳排智能追踪'
    ],
    benefits: [
      '能源利用效率提升25-40%',
      '运营成本降低20-35%',
      '碳排放减少30-50%',
      '设备寿命延长20%'
    ],
    tools: [
      { name: '施耐德EcoStruxure', type: '能效管理平台', link: 'https://se.com/ecostruxure' },
      { name: 'ABB Ability', type: '能源管理平台', link: 'https://abb.com/ability' },
      { name: '阿里云能源云', type: '能源AI平台', link: 'https://aliyun.com/energy' },
      { name: '腾讯云智慧能源', type: '能源数字化平台', link: 'https://cloud.tencent.com/energy' }
    ],
    flowchartSteps: [
      '能源需求智能预测',
      '发电/购电智能调度',
      '电网实时状态监控',
      '用能设备智能控制',
      '能效数据实时分析',
      '储能系统智能管理',
      '碳排数据追踪报告',
      '持续优化策略生成'
    ]
  }
]

// 其他垂直领域
const otherVerticals = [
  {
    id: 3,
    title: '医疗健康AI Agent',
    category: '医疗健康',
    description: '智能诊断辅助、个性化治疗方案、医疗资源优化',
    keyApplications: ['智能分诊', '影像诊断辅助', '药物研发', '慢病管理'],
    commercialValue: '医疗效率提升50%，误诊率降低40%'
  },
  {
    id: 4,
    title: '金融服务智能代理',
    category: '金融服务',
    description: '智能投顾、风险控制、反欺诈、客户服务',
    keyApplications: ['智能投顾', '信贷风险评估', '交易监控', '客户服务'],
    commercialValue: '运营成本降低60%，客户满意度提升35%'
  },
  {
    id: 5,
    title: '教育个性化Agent',
    category: '教育培训',
    description: '个性化学习路径、智能辅导、学习效果评估',
    keyApplications: ['学习路径规划', '知识点诊断', '智能答疑', '学习效果跟踪'],
    commercialValue: '学习效率提升45%，教师工作量减少50%'
  }
]

export default function VerticalAgentSection() {
  const [expandedId, setExpandedId] = useState<number | null>(1)
  const [activeTab, setActiveTab] = useState<'industrial' | 'other'>('industrial')

  const handleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id)
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      {/* 标题和价值主张 */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold flex items-center text-green-700 dark:text-green-400">
          <Factory className="mr-3 h-7 w-7" />
          Agent垂直应用 · 行业赋能
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mt-3 text-lg">
          提供AI Agent技术在垂直领域的深度应用洞察与决策支持，帮助从信息洪流中提炼可落地的商业价值
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="px-3 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 rounded-full text-sm">
            技术普惠
          </span>
          <span className="px-3 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 rounded-full text-sm">
            行业赋能
          </span>
          <span className="px-3 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 rounded-full text-sm">
            决策支持
          </span>
          <span className="px-3 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 rounded-full text-sm">
            商业价值
          </span>
        </div>
      </div>

      {/* 标签切换 */}
      <div className="mb-6">
        <div className="flex border-b border-gray-200 dark:border-gray-700">
          <button
            onClick={() => setActiveTab('industrial')}
            className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors ${
              activeTab === 'industrial'
                ? 'border-green-500 text-green-600 dark:text-green-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
          >
            <Factory className="inline h-4 w-4 mr-2" />
            工业能源场景
          </button>
          <button
            onClick={() => setActiveTab('other')}
            className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors ${
              activeTab === 'other'
                ? 'border-green-500 text-green-600 dark:text-green-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
          >
            <Users className="inline h-4 w-4 mr-2" />
            其他垂直领域
          </button>
        </div>
      </div>

      {/* 工业能源场景内容 */}
      {activeTab === 'industrial' && (
        <div className="space-y-6">
          {industrialScenarios.map((scenario) => (
            <div
              key={scenario.id}
              className={`border rounded-lg overflow-hidden transition-all duration-300 ${
                expandedId === scenario.id
                  ? 'border-green-300 dark:border-green-700 bg-green-50 dark:bg-green-900/20'
                  : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
              }`}
            >
              {/* 场景头部 */}
              <div 
                className="p-5 cursor-pointer"
                onClick={() => handleExpand(scenario.id)}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center mb-3">
                      <span className="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-xs font-medium">
                        {scenario.category}
                      </span>
                      <span className="mx-3 text-gray-400">•</span>
                      <span className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                        <TrendingUp className="h-4 w-4 mr-1" />
                        商业价值显著
                      </span>
                    </div>
                    
                    <h3 className="text-xl font-semibold mb-3">
                      {scenario.title}
                    </h3>
                    
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      {scenario.description}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center text-sm text-gray-500">
                          <Cpu className="h-4 w-4 mr-1" />
                          {scenario.stages.length}个关键阶段
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Zap className="h-4 w-4 mr-1" />
                          {scenario.benefits.length}项核心效益
                        </div>
                      </div>
                      
                      <button className="text-green-500 hover:text-green-600 text-sm font-medium">
                        {expandedId === scenario.id ? '收起详情' : '查看全流程图'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* 展开的详情 */}
              {expandedId === scenario.id && (
                <div className="px-5 pb-5 pt-3 border-t border-gray-200 dark:border-gray-700 animate-slide-up">
                  {/* 全流程生产应用流程图 */}
                  <div className="mb-6">
                    <h4 className="font-medium mb-3 flex items-center text-green-600 dark:text-green-400">
                      <BarChart className="h-5 w-5 mr-2" />
                      智能化全流程生产应用流程图
                    </h4>
                    <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
                      <div className="space-y-3">
                        {scenario.flowchartSteps.map((step, index) => (
                          <div key={index} className="flex items-center">
                            <div className="w-8 h-8 flex items-center justify-center bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 rounded-full text-sm font-bold mr-3">
                              {index + 1}
                            </div>
                            <div className="flex-1 py-2 px-4 bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700">
                              {step}
                            </div>
                            {index < scenario.flowchartSteps.length - 1 && (
                              <div className="mx-4 text-gray-400">↓</div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  {/* 核心效益 */}
                  <div className="mb-6">
                    <h4 className="font-medium mb-3">核心商业效益</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {scenario.benefits.map((benefit, index) => (
                        <div key={index} className="flex items-center p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
                          <div className="w-8 h-8 flex items-center justify-center bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 rounded-full mr-3">
                            ✓
                          </div>
                          <span className="text-gray-700 dark:text-gray-300">{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* 现实链工具 */}
                  <div className="mb-6">
                    <h4 className="font-medium mb-3 flex items-center">
                      <Wrench className="h-5 w-5 mr-2" />
                      现实可用工具链
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {scenario.tools.map((tool, index) => (
                        <a
                          key={index}
                          href={tool.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-green-300 dark:hover:border-green-700 transition-colors"
                        >
                          <div className="font-medium text-gray-900 dark:text-white mb-1">
                            {tool.name}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                            {tool.type}
                          </div>
                          <div className="text-xs text-green-600 dark:text-green-400">
                            点击查看详情 →
                          </div>
                        </a>
                      ))}
                    </div>
                  </div>
                  
                  {/* 实施建议 */}
                  <div className="bg-green-50 dark:bg-green-900/30 rounded-lg p-4">
                    <h4 className="font-medium mb-2 text-green-700 dark:text-green-400">
                      实施建议
                    </h4>
                    <ul className="text-sm text-gray-700 dark:text-gray-300 space-y-2">
                      <li className="flex items-start">
                        <span className="text-green-500 mr-2">•</span>
                        <span>建议分阶段实施，先从1-2个关键环节开始</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-green-500 mr-2">•</span>
                        <span>选择与现有系统兼容性好的工具平台</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-green-500 mr-2">•</span>
                        <span>建立跨部门实施团队，包括IT、业务、运营人员</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-green-500 mr-2">•</span>
                        <span>设定明确的ROI指标和验收标准</span>
                      </li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* 其他垂直领域 */}
      {activeTab === 'other' && (
        <div className="space-y-6">
          {otherVerticals.map((vertical) => (
            <div
              key={vertical.id}
              className="border border-gray-200 dark:border-gray-700 rounded-lg p-5 hover:border-gray-300 dark:hover:border-gray-600 transition-colors"
            >
              <div className="flex items-start mb-4">
                <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg mr-4">
                  {vertical.category === '医疗健康' && '🏥'}
                  {vertical.category === '金融服务' && '💰'}
                  {vertical.category === '教育培训' && '🎓'}
                </div>
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    <span className="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-xs font-medium">
                      {vertical.category}
                    </span>
                    <span className="mx-3 text-gray-400">•</span>
                    <span className="text-sm text-green-600 dark:text-green-400">
                      {vertical.commercialValue}
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">
                    {vertical.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    {vertical.description}
                  </p>
                  
                  <div className="mb-4">
                    <h4 className="text-sm font-medium mb-2">关键应用场景</h4>
                    <div className="flex flex-wrap gap-2">
                      {vertical.keyApplications.map((app, idx) => (
                        <span key={idx} className="px-3 py-1 bg-gray-100 dark:bg-gray-700 rounded-full text-xs">
                          {app}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="text-sm text-gray-500">
                      点击查看详细实施方案 →
                    </div>
                    <button className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm font-medium transition-colors">
                      获取行业报告
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 底部行动 */}
      <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h4 className="font-medium mb-2">获取深度行业分析</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              提供完整的行业落地方案、ROI分析和实施路线图
            </p>
          </div>
          <div className="flex space-x-3">
            <button className="px-5 py-2.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg font-medium transition-colors">
              下载行业白皮书
            </button>
            <button className="px-5 py-2.5 bg-green-500 hover:bg-green-600 text-white rounded-lg font-medium transition-colors flex items-center">
              <Download className="h-4 w-4 mr-2" />
              获取实施工具包
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}