'use client'

import { TrendingUp, Calendar, Database, Zap, Clock } from 'lucide-react'
import { useState, useEffect } from 'react'

interface StatsOverviewProps {
  stats: {
    totalArticles: number
    dailyUpdates: number
    agentProjects: number
    constructionCases: number
    lastUpdated: string
  }
}

export default function StatsOverview({ stats }: StatsOverviewProps) {
  const [animatedStats, setAnimatedStats] = useState({
    totalArticles: 0,
    dailyUpdates: 0,
    agentProjects: 0,
    constructionCases: 0,
  })

  useEffect(() => {
    // 数字动画效果
    const animateValue = (start: number, end: number, duration: number, callback: (value: number) => void) => {
      const startTime = Date.now()
      const updateValue = () => {
        const elapsed = Date.now() - startTime
        const progress = Math.min(elapsed / duration, 1)
        const current = Math.floor(start + (end - start) * progress)
        callback(current)
        
        if (progress < 1) {
          requestAnimationFrame(updateValue)
        }
      }
      requestAnimationFrame(updateValue)
    }

    // 依次动画显示各个统计数字
    const delays = [0, 200, 400, 600]
    const statsToAnimate = [
      { key: 'totalArticles', value: stats.totalArticles },
      { key: 'dailyUpdates', value: stats.dailyUpdates },
      { key: 'agentProjects', value: stats.agentProjects },
      { key: 'constructionCases', value: stats.constructionCases },
    ]

    statsToAnimate.forEach((stat, index) => {
      setTimeout(() => {
        animateValue(0, stat.value, 1000, (value) => {
          setAnimatedStats(prev => ({
            ...prev,
            [stat.key]: value
          }))
        })
      }, delays[index])
    })
  }, [stats])

  const statCards = [
    {
      title: '资讯总量',
      value: animatedStats.totalArticles,
      icon: <Database className="h-6 w-6" />,
      color: 'from-blue-500 to-blue-600',
      description: '累计收录AI相关资讯',
    },
    {
      title: '每日更新',
      value: animatedStats.dailyUpdates,
      icon: <Calendar className="h-6 w-6" />,
      color: 'from-green-500 to-green-600',
      description: '今日已更新资讯数',
    },
    {
      title: 'Agent项目',
      value: animatedStats.agentProjects,
      icon: <Zap className="h-6 w-6" />,
      color: 'from-purple-500 to-purple-600',
      description: '开源Agent应用案例',
    },
    {
      title: '建造案例',
      value: animatedStats.constructionCases,
      icon: <TrendingUp className="h-6 w-6" />,
      color: 'from-orange-500 to-orange-600',
      description: '智能建造落地应用',
    },
  ]

  return (
    <div className="mb-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <div
            key={stat.title}
            className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm border border-gray-100 dark:border-gray-700 card-hover"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-lg bg-gradient-to-br ${stat.color}`}>
                <div className="text-white">{stat.icon}</div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-gray-900 dark:text-white">
                  {stat.value.toLocaleString()}
                </div>
                <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  {stat.title}
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {stat.description}
            </p>
            <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700 flex items-center text-xs text-gray-500">
              <Clock className="h-3 w-3 mr-1" />
              <span>实时更新</span>
            </div>
          </div>
        ))}
      </div>
      
      {/* 更新时间 */}
      <div className="mt-4 text-center text-sm text-gray-500 dark:text-gray-400">
        <div className="inline-flex items-center px-3 py-1 rounded-full bg-gray-100 dark:bg-gray-800">
          <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
          最后更新: {stats.lastUpdated}
          <button 
            className="ml-3 text-blue-500 hover:text-blue-600 transition-colors"
            onClick={() => window.location.reload()}
          >
            刷新数据
          </button>
        </div>
      </div>
    </div>
  )
}