'use client'

import { useEffect, useState } from 'react'
import { Smartphone, Monitor, RefreshCw } from 'lucide-react'

export default function PlatformNotice() {
  const [platform, setPlatform] = useState<'pc' | 'mobile' | 'detecting'>('detecting')
  const [showNotice, setShowNotice] = useState(true)

  useEffect(() => {
    // 模拟平台检测
    const detectPlatform = () => {
      const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent)
      setPlatform(isMobile ? 'mobile' : 'pc')
      
      // 存储检测结果
      sessionStorage.setItem('detectedPlatform', isMobile ? 'mobile' : 'pc')
    }

    detectPlatform()
    
    // 5秒后自动隐藏通知
    const timer = setTimeout(() => {
      setShowNotice(false)
    }, 5000)

    return () => clearTimeout(timer)
  }, [])

  const handleSwitchPlatform = () => {
    const newPlatform = platform === 'mobile' ? 'pc' : 'mobile'
    setPlatform(newPlatform)
    
    // 在实际应用中，这里会触发布局切换
    console.log(`切换到${newPlatform === 'mobile' ? '移动' : 'PC'}模式`)
    
    // 重新显示通知
    setShowNotice(true)
    
    // 3秒后再次隐藏
    setTimeout(() => setShowNotice(false), 3000)
  }

  if (!showNotice) return null

  return (
    <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg p-4 mb-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {platform === 'mobile' ? (
            <Smartphone className="h-5 w-5" />
          ) : platform === 'pc' ? (
            <Monitor className="h-5 w-5" />
          ) : (
            <RefreshCw className="h-5 w-5 animate-spin" />
          )}
          
          <div>
            <p className="font-medium">
              {platform === 'detecting' 
                ? '正在检测您的设备...' 
                : `已为您优化${platform === 'mobile' ? '移动' : 'PC'}端阅读体验`
              }
            </p>
            <p className="text-sm text-blue-100 opacity-90">
              {platform === 'mobile' 
                ? '界面已适配小屏幕，点击按钮可切换PC视图' 
                : platform === 'pc' 
                  ? '界面已适配大屏幕，点击按钮可切换移动视图'
                  : '自动检测中...'
              }
            </p>
          </div>
        </div>
        
        {platform !== 'detecting' && (
          <button
            onClick={handleSwitchPlatform}
            className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2"
          >
            <RefreshCw className="h-4 w-4" />
            <span>切换{platform === 'mobile' ? 'PC' : '移动'}模式</span>
          </button>
        )}
      </div>
      
      {/* 进度条 */}
      <div className="mt-3 h-1 bg-white/20 rounded-full overflow-hidden">
        <div 
          className="h-full bg-white transition-all duration-5000"
          style={{ 
            width: platform === 'detecting' ? '60%' : '100%',
            animation: platform === 'detecting' ? 'pulse 2s infinite' : 'none'
          }}
        />
      </div>
    </div>
  )
}